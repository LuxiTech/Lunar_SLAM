// generated from rosidl_generator_py/resource/_idl_support.c.em
// with input from ddt_msgs:msg/DockStatus.idl
// generated code does not contain a copyright notice
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <Python.h>
#include <stdbool.h>
#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-function"
#endif
#include "numpy/ndarrayobject.h"
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif
#include "rosidl_runtime_c/visibility_control.h"
#include "ddt_msgs/msg/detail/dock_status__struct.h"
#include "ddt_msgs/msg/detail/dock_status__functions.h"

ROSIDL_GENERATOR_C_IMPORT
bool std_msgs__msg__header__convert_from_py(PyObject * _pymsg, void * _ros_message);
ROSIDL_GENERATOR_C_IMPORT
PyObject * std_msgs__msg__header__convert_to_py(void * raw_ros_message);

ROSIDL_GENERATOR_C_EXPORT
bool ddt_msgs__msg__dock_status__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[37];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("ddt_msgs.msg._dock_status.DockStatus", full_classname_dest, 36) == 0);
  }
  ddt_msgs__msg__DockStatus * ros_message = _ros_message;
  {  // header
    PyObject * field = PyObject_GetAttrString(_pymsg, "header");
    if (!field) {
      return false;
    }
    if (!std_msgs__msg__header__convert_from_py(field, &ros_message->header)) {
      Py_DECREF(field);
      return false;
    }
    Py_DECREF(field);
  }
  {  // present
    PyObject * field = PyObject_GetAttrString(_pymsg, "present");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->present = (Py_True == field);
    Py_DECREF(field);
  }
  {  // slave
    PyObject * field = PyObject_GetAttrString(_pymsg, "slave");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->slave = (Py_True == field);
    Py_DECREF(field);
  }
  {  // connect
    PyObject * field = PyObject_GetAttrString(_pymsg, "connect");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->connect = (Py_True == field);
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * ddt_msgs__msg__dock_status__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of DockStatus */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("ddt_msgs.msg._dock_status");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "DockStatus");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  ddt_msgs__msg__DockStatus * ros_message = (ddt_msgs__msg__DockStatus *)raw_ros_message;
  {  // header
    PyObject * field = NULL;
    field = std_msgs__msg__header__convert_to_py(&ros_message->header);
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "header", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // present
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->present ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "present", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // slave
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->slave ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "slave", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // connect
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->connect ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "connect", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}
