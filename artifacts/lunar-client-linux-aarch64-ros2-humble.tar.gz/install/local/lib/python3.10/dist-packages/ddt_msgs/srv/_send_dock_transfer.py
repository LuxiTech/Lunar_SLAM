# generated from rosidl_generator_py/resource/_idl.py.em
# with input from ddt_msgs:srv/SendDockTransfer.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_SendDockTransfer_Request(type):
    """Metaclass of message 'SendDockTransfer_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'MSG_TYPE_ACK': 0,
        'MSG_TYPE_COMMAND': 1,
        'MSG_TYPE_E_STOP': 15,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('ddt_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'ddt_msgs.srv.SendDockTransfer_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__send_dock_transfer__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__send_dock_transfer__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__send_dock_transfer__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__send_dock_transfer__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__send_dock_transfer__request

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'MSG_TYPE_ACK': cls.__constants['MSG_TYPE_ACK'],
            'MSG_TYPE_COMMAND': cls.__constants['MSG_TYPE_COMMAND'],
            'MSG_TYPE_E_STOP': cls.__constants['MSG_TYPE_E_STOP'],
        }

    @property
    def MSG_TYPE_ACK(self):
        """Message constant 'MSG_TYPE_ACK'."""
        return Metaclass_SendDockTransfer_Request.__constants['MSG_TYPE_ACK']

    @property
    def MSG_TYPE_COMMAND(self):
        """Message constant 'MSG_TYPE_COMMAND'."""
        return Metaclass_SendDockTransfer_Request.__constants['MSG_TYPE_COMMAND']

    @property
    def MSG_TYPE_E_STOP(self):
        """Message constant 'MSG_TYPE_E_STOP'."""
        return Metaclass_SendDockTransfer_Request.__constants['MSG_TYPE_E_STOP']


class SendDockTransfer_Request(metaclass=Metaclass_SendDockTransfer_Request):
    """
    Message class 'SendDockTransfer_Request'.

    Constants:
      MSG_TYPE_ACK
      MSG_TYPE_COMMAND
      MSG_TYPE_E_STOP
    """

    __slots__ = [
        '_type',
        '_is_slave',
        '_is_quadruped',
        '_is_balance',
    ]

    _fields_and_field_types = {
        'type': 'uint8',
        'is_slave': 'boolean',
        'is_quadruped': 'boolean',
        'is_balance': 'boolean',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.type = kwargs.get('type', int())
        self.is_slave = kwargs.get('is_slave', bool())
        self.is_quadruped = kwargs.get('is_quadruped', bool())
        self.is_balance = kwargs.get('is_balance', bool())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.type != other.type:
            return False
        if self.is_slave != other.is_slave:
            return False
        if self.is_quadruped != other.is_quadruped:
            return False
        if self.is_balance != other.is_balance:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property  # noqa: A003
    def type(self):  # noqa: A003
        """Message field 'type'."""
        return self._type

    @type.setter  # noqa: A003
    def type(self, value):  # noqa: A003
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'type' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'type' field must be an unsigned integer in [0, 255]"
        self._type = value

    @builtins.property
    def is_slave(self):
        """Message field 'is_slave'."""
        return self._is_slave

    @is_slave.setter
    def is_slave(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'is_slave' field must be of type 'bool'"
        self._is_slave = value

    @builtins.property
    def is_quadruped(self):
        """Message field 'is_quadruped'."""
        return self._is_quadruped

    @is_quadruped.setter
    def is_quadruped(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'is_quadruped' field must be of type 'bool'"
        self._is_quadruped = value

    @builtins.property
    def is_balance(self):
        """Message field 'is_balance'."""
        return self._is_balance

    @is_balance.setter
    def is_balance(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'is_balance' field must be of type 'bool'"
        self._is_balance = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_SendDockTransfer_Response(type):
    """Metaclass of message 'SendDockTransfer_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('ddt_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'ddt_msgs.srv.SendDockTransfer_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__send_dock_transfer__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__send_dock_transfer__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__send_dock_transfer__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__send_dock_transfer__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__send_dock_transfer__response

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class SendDockTransfer_Response(metaclass=Metaclass_SendDockTransfer_Response):
    """Message class 'SendDockTransfer_Response'."""

    __slots__ = [
        '_success',
        '_message',
    ]

    _fields_and_field_types = {
        'success': 'boolean',
        'message': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.success = kwargs.get('success', bool())
        self.message = kwargs.get('message', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.success != other.success:
            return False
        if self.message != other.message:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def success(self):
        """Message field 'success'."""
        return self._success

    @success.setter
    def success(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'success' field must be of type 'bool'"
        self._success = value

    @builtins.property
    def message(self):
        """Message field 'message'."""
        return self._message

    @message.setter
    def message(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'message' field must be of type 'str'"
        self._message = value


class Metaclass_SendDockTransfer(type):
    """Metaclass of service 'SendDockTransfer'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('ddt_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'ddt_msgs.srv.SendDockTransfer')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__send_dock_transfer

            from ddt_msgs.srv import _send_dock_transfer
            if _send_dock_transfer.Metaclass_SendDockTransfer_Request._TYPE_SUPPORT is None:
                _send_dock_transfer.Metaclass_SendDockTransfer_Request.__import_type_support__()
            if _send_dock_transfer.Metaclass_SendDockTransfer_Response._TYPE_SUPPORT is None:
                _send_dock_transfer.Metaclass_SendDockTransfer_Response.__import_type_support__()


class SendDockTransfer(metaclass=Metaclass_SendDockTransfer):
    from ddt_msgs.srv._send_dock_transfer import SendDockTransfer_Request as Request
    from ddt_msgs.srv._send_dock_transfer import SendDockTransfer_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
