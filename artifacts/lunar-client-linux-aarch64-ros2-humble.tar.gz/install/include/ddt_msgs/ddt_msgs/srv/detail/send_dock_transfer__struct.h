// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from ddt_msgs:srv/SendDockTransfer.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__SRV__DETAIL__SEND_DOCK_TRANSFER__STRUCT_H_
#define DDT_MSGS__SRV__DETAIL__SEND_DOCK_TRANSFER__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'MSG_TYPE_ACK'.
/**
  * Request
 */
enum
{
  ddt_msgs__srv__SendDockTransfer_Request__MSG_TYPE_ACK = 0
};

/// Constant 'MSG_TYPE_COMMAND'.
enum
{
  ddt_msgs__srv__SendDockTransfer_Request__MSG_TYPE_COMMAND = 1
};

/// Constant 'MSG_TYPE_E_STOP'.
enum
{
  ddt_msgs__srv__SendDockTransfer_Request__MSG_TYPE_E_STOP = 15
};

/// Struct defined in srv/SendDockTransfer in the package ddt_msgs.
typedef struct ddt_msgs__srv__SendDockTransfer_Request
{
  /// Message type
  uint8_t type;
  /// true=Slave robot, false=Master robot
  bool is_slave;
  /// true=Quadruped mode, false=Biped mode
  bool is_quadruped;
  /// true=Balance mode, false=Cart mode (only for COMMAND)
  bool is_balance;
} ddt_msgs__srv__SendDockTransfer_Request;

// Struct for a sequence of ddt_msgs__srv__SendDockTransfer_Request.
typedef struct ddt_msgs__srv__SendDockTransfer_Request__Sequence
{
  ddt_msgs__srv__SendDockTransfer_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} ddt_msgs__srv__SendDockTransfer_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/SendDockTransfer in the package ddt_msgs.
typedef struct ddt_msgs__srv__SendDockTransfer_Response
{
  bool success;
  rosidl_runtime_c__String message;
} ddt_msgs__srv__SendDockTransfer_Response;

// Struct for a sequence of ddt_msgs__srv__SendDockTransfer_Response.
typedef struct ddt_msgs__srv__SendDockTransfer_Response__Sequence
{
  ddt_msgs__srv__SendDockTransfer_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} ddt_msgs__srv__SendDockTransfer_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DDT_MSGS__SRV__DETAIL__SEND_DOCK_TRANSFER__STRUCT_H_
