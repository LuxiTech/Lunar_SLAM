// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from ddt_msgs:srv/SendDockTransfer.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__SRV__DETAIL__SEND_DOCK_TRANSFER__BUILDER_HPP_
#define DDT_MSGS__SRV__DETAIL__SEND_DOCK_TRANSFER__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "ddt_msgs/srv/detail/send_dock_transfer__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace ddt_msgs
{

namespace srv
{

namespace builder
{

class Init_SendDockTransfer_Request_is_balance
{
public:
  explicit Init_SendDockTransfer_Request_is_balance(::ddt_msgs::srv::SendDockTransfer_Request & msg)
  : msg_(msg)
  {}
  ::ddt_msgs::srv::SendDockTransfer_Request is_balance(::ddt_msgs::srv::SendDockTransfer_Request::_is_balance_type arg)
  {
    msg_.is_balance = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ddt_msgs::srv::SendDockTransfer_Request msg_;
};

class Init_SendDockTransfer_Request_is_quadruped
{
public:
  explicit Init_SendDockTransfer_Request_is_quadruped(::ddt_msgs::srv::SendDockTransfer_Request & msg)
  : msg_(msg)
  {}
  Init_SendDockTransfer_Request_is_balance is_quadruped(::ddt_msgs::srv::SendDockTransfer_Request::_is_quadruped_type arg)
  {
    msg_.is_quadruped = std::move(arg);
    return Init_SendDockTransfer_Request_is_balance(msg_);
  }

private:
  ::ddt_msgs::srv::SendDockTransfer_Request msg_;
};

class Init_SendDockTransfer_Request_is_slave
{
public:
  explicit Init_SendDockTransfer_Request_is_slave(::ddt_msgs::srv::SendDockTransfer_Request & msg)
  : msg_(msg)
  {}
  Init_SendDockTransfer_Request_is_quadruped is_slave(::ddt_msgs::srv::SendDockTransfer_Request::_is_slave_type arg)
  {
    msg_.is_slave = std::move(arg);
    return Init_SendDockTransfer_Request_is_quadruped(msg_);
  }

private:
  ::ddt_msgs::srv::SendDockTransfer_Request msg_;
};

class Init_SendDockTransfer_Request_type
{
public:
  Init_SendDockTransfer_Request_type()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SendDockTransfer_Request_is_slave type(::ddt_msgs::srv::SendDockTransfer_Request::_type_type arg)
  {
    msg_.type = std::move(arg);
    return Init_SendDockTransfer_Request_is_slave(msg_);
  }

private:
  ::ddt_msgs::srv::SendDockTransfer_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::ddt_msgs::srv::SendDockTransfer_Request>()
{
  return ddt_msgs::srv::builder::Init_SendDockTransfer_Request_type();
}

}  // namespace ddt_msgs


namespace ddt_msgs
{

namespace srv
{

namespace builder
{

class Init_SendDockTransfer_Response_message
{
public:
  explicit Init_SendDockTransfer_Response_message(::ddt_msgs::srv::SendDockTransfer_Response & msg)
  : msg_(msg)
  {}
  ::ddt_msgs::srv::SendDockTransfer_Response message(::ddt_msgs::srv::SendDockTransfer_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ddt_msgs::srv::SendDockTransfer_Response msg_;
};

class Init_SendDockTransfer_Response_success
{
public:
  Init_SendDockTransfer_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SendDockTransfer_Response_message success(::ddt_msgs::srv::SendDockTransfer_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_SendDockTransfer_Response_message(msg_);
  }

private:
  ::ddt_msgs::srv::SendDockTransfer_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::ddt_msgs::srv::SendDockTransfer_Response>()
{
  return ddt_msgs::srv::builder::Init_SendDockTransfer_Response_success();
}

}  // namespace ddt_msgs

#endif  // DDT_MSGS__SRV__DETAIL__SEND_DOCK_TRANSFER__BUILDER_HPP_
