// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from ddt_msgs:srv/SendDockTransfer.idl
// generated code does not contain a copyright notice
#include "ddt_msgs/srv/detail/send_dock_transfer__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"

bool
ddt_msgs__srv__SendDockTransfer_Request__init(ddt_msgs__srv__SendDockTransfer_Request * msg)
{
  if (!msg) {
    return false;
  }
  // type
  // is_slave
  // is_quadruped
  // is_balance
  return true;
}

void
ddt_msgs__srv__SendDockTransfer_Request__fini(ddt_msgs__srv__SendDockTransfer_Request * msg)
{
  if (!msg) {
    return;
  }
  // type
  // is_slave
  // is_quadruped
  // is_balance
}

bool
ddt_msgs__srv__SendDockTransfer_Request__are_equal(const ddt_msgs__srv__SendDockTransfer_Request * lhs, const ddt_msgs__srv__SendDockTransfer_Request * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // type
  if (lhs->type != rhs->type) {
    return false;
  }
  // is_slave
  if (lhs->is_slave != rhs->is_slave) {
    return false;
  }
  // is_quadruped
  if (lhs->is_quadruped != rhs->is_quadruped) {
    return false;
  }
  // is_balance
  if (lhs->is_balance != rhs->is_balance) {
    return false;
  }
  return true;
}

bool
ddt_msgs__srv__SendDockTransfer_Request__copy(
  const ddt_msgs__srv__SendDockTransfer_Request * input,
  ddt_msgs__srv__SendDockTransfer_Request * output)
{
  if (!input || !output) {
    return false;
  }
  // type
  output->type = input->type;
  // is_slave
  output->is_slave = input->is_slave;
  // is_quadruped
  output->is_quadruped = input->is_quadruped;
  // is_balance
  output->is_balance = input->is_balance;
  return true;
}

ddt_msgs__srv__SendDockTransfer_Request *
ddt_msgs__srv__SendDockTransfer_Request__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ddt_msgs__srv__SendDockTransfer_Request * msg = (ddt_msgs__srv__SendDockTransfer_Request *)allocator.allocate(sizeof(ddt_msgs__srv__SendDockTransfer_Request), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(ddt_msgs__srv__SendDockTransfer_Request));
  bool success = ddt_msgs__srv__SendDockTransfer_Request__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
ddt_msgs__srv__SendDockTransfer_Request__destroy(ddt_msgs__srv__SendDockTransfer_Request * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    ddt_msgs__srv__SendDockTransfer_Request__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
ddt_msgs__srv__SendDockTransfer_Request__Sequence__init(ddt_msgs__srv__SendDockTransfer_Request__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ddt_msgs__srv__SendDockTransfer_Request * data = NULL;

  if (size) {
    data = (ddt_msgs__srv__SendDockTransfer_Request *)allocator.zero_allocate(size, sizeof(ddt_msgs__srv__SendDockTransfer_Request), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = ddt_msgs__srv__SendDockTransfer_Request__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        ddt_msgs__srv__SendDockTransfer_Request__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
ddt_msgs__srv__SendDockTransfer_Request__Sequence__fini(ddt_msgs__srv__SendDockTransfer_Request__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      ddt_msgs__srv__SendDockTransfer_Request__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

ddt_msgs__srv__SendDockTransfer_Request__Sequence *
ddt_msgs__srv__SendDockTransfer_Request__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ddt_msgs__srv__SendDockTransfer_Request__Sequence * array = (ddt_msgs__srv__SendDockTransfer_Request__Sequence *)allocator.allocate(sizeof(ddt_msgs__srv__SendDockTransfer_Request__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = ddt_msgs__srv__SendDockTransfer_Request__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
ddt_msgs__srv__SendDockTransfer_Request__Sequence__destroy(ddt_msgs__srv__SendDockTransfer_Request__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    ddt_msgs__srv__SendDockTransfer_Request__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
ddt_msgs__srv__SendDockTransfer_Request__Sequence__are_equal(const ddt_msgs__srv__SendDockTransfer_Request__Sequence * lhs, const ddt_msgs__srv__SendDockTransfer_Request__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!ddt_msgs__srv__SendDockTransfer_Request__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
ddt_msgs__srv__SendDockTransfer_Request__Sequence__copy(
  const ddt_msgs__srv__SendDockTransfer_Request__Sequence * input,
  ddt_msgs__srv__SendDockTransfer_Request__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(ddt_msgs__srv__SendDockTransfer_Request);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    ddt_msgs__srv__SendDockTransfer_Request * data =
      (ddt_msgs__srv__SendDockTransfer_Request *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!ddt_msgs__srv__SendDockTransfer_Request__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          ddt_msgs__srv__SendDockTransfer_Request__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!ddt_msgs__srv__SendDockTransfer_Request__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `message`
#include "rosidl_runtime_c/string_functions.h"

bool
ddt_msgs__srv__SendDockTransfer_Response__init(ddt_msgs__srv__SendDockTransfer_Response * msg)
{
  if (!msg) {
    return false;
  }
  // success
  // message
  if (!rosidl_runtime_c__String__init(&msg->message)) {
    ddt_msgs__srv__SendDockTransfer_Response__fini(msg);
    return false;
  }
  return true;
}

void
ddt_msgs__srv__SendDockTransfer_Response__fini(ddt_msgs__srv__SendDockTransfer_Response * msg)
{
  if (!msg) {
    return;
  }
  // success
  // message
  rosidl_runtime_c__String__fini(&msg->message);
}

bool
ddt_msgs__srv__SendDockTransfer_Response__are_equal(const ddt_msgs__srv__SendDockTransfer_Response * lhs, const ddt_msgs__srv__SendDockTransfer_Response * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // success
  if (lhs->success != rhs->success) {
    return false;
  }
  // message
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->message), &(rhs->message)))
  {
    return false;
  }
  return true;
}

bool
ddt_msgs__srv__SendDockTransfer_Response__copy(
  const ddt_msgs__srv__SendDockTransfer_Response * input,
  ddt_msgs__srv__SendDockTransfer_Response * output)
{
  if (!input || !output) {
    return false;
  }
  // success
  output->success = input->success;
  // message
  if (!rosidl_runtime_c__String__copy(
      &(input->message), &(output->message)))
  {
    return false;
  }
  return true;
}

ddt_msgs__srv__SendDockTransfer_Response *
ddt_msgs__srv__SendDockTransfer_Response__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ddt_msgs__srv__SendDockTransfer_Response * msg = (ddt_msgs__srv__SendDockTransfer_Response *)allocator.allocate(sizeof(ddt_msgs__srv__SendDockTransfer_Response), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(ddt_msgs__srv__SendDockTransfer_Response));
  bool success = ddt_msgs__srv__SendDockTransfer_Response__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
ddt_msgs__srv__SendDockTransfer_Response__destroy(ddt_msgs__srv__SendDockTransfer_Response * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    ddt_msgs__srv__SendDockTransfer_Response__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
ddt_msgs__srv__SendDockTransfer_Response__Sequence__init(ddt_msgs__srv__SendDockTransfer_Response__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ddt_msgs__srv__SendDockTransfer_Response * data = NULL;

  if (size) {
    data = (ddt_msgs__srv__SendDockTransfer_Response *)allocator.zero_allocate(size, sizeof(ddt_msgs__srv__SendDockTransfer_Response), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = ddt_msgs__srv__SendDockTransfer_Response__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        ddt_msgs__srv__SendDockTransfer_Response__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
ddt_msgs__srv__SendDockTransfer_Response__Sequence__fini(ddt_msgs__srv__SendDockTransfer_Response__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      ddt_msgs__srv__SendDockTransfer_Response__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

ddt_msgs__srv__SendDockTransfer_Response__Sequence *
ddt_msgs__srv__SendDockTransfer_Response__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ddt_msgs__srv__SendDockTransfer_Response__Sequence * array = (ddt_msgs__srv__SendDockTransfer_Response__Sequence *)allocator.allocate(sizeof(ddt_msgs__srv__SendDockTransfer_Response__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = ddt_msgs__srv__SendDockTransfer_Response__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
ddt_msgs__srv__SendDockTransfer_Response__Sequence__destroy(ddt_msgs__srv__SendDockTransfer_Response__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    ddt_msgs__srv__SendDockTransfer_Response__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
ddt_msgs__srv__SendDockTransfer_Response__Sequence__are_equal(const ddt_msgs__srv__SendDockTransfer_Response__Sequence * lhs, const ddt_msgs__srv__SendDockTransfer_Response__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!ddt_msgs__srv__SendDockTransfer_Response__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
ddt_msgs__srv__SendDockTransfer_Response__Sequence__copy(
  const ddt_msgs__srv__SendDockTransfer_Response__Sequence * input,
  ddt_msgs__srv__SendDockTransfer_Response__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(ddt_msgs__srv__SendDockTransfer_Response);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    ddt_msgs__srv__SendDockTransfer_Response * data =
      (ddt_msgs__srv__SendDockTransfer_Response *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!ddt_msgs__srv__SendDockTransfer_Response__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          ddt_msgs__srv__SendDockTransfer_Response__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!ddt_msgs__srv__SendDockTransfer_Response__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
