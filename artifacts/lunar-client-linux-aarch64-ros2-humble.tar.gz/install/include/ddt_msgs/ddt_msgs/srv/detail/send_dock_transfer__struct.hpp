// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from ddt_msgs:srv/SendDockTransfer.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__SRV__DETAIL__SEND_DOCK_TRANSFER__STRUCT_HPP_
#define DDT_MSGS__SRV__DETAIL__SEND_DOCK_TRANSFER__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__ddt_msgs__srv__SendDockTransfer_Request __attribute__((deprecated))
#else
# define DEPRECATED__ddt_msgs__srv__SendDockTransfer_Request __declspec(deprecated)
#endif

namespace ddt_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct SendDockTransfer_Request_
{
  using Type = SendDockTransfer_Request_<ContainerAllocator>;

  explicit SendDockTransfer_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->type = 0;
      this->is_slave = false;
      this->is_quadruped = false;
      this->is_balance = false;
    }
  }

  explicit SendDockTransfer_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->type = 0;
      this->is_slave = false;
      this->is_quadruped = false;
      this->is_balance = false;
    }
  }

  // field types and members
  using _type_type =
    uint8_t;
  _type_type type;
  using _is_slave_type =
    bool;
  _is_slave_type is_slave;
  using _is_quadruped_type =
    bool;
  _is_quadruped_type is_quadruped;
  using _is_balance_type =
    bool;
  _is_balance_type is_balance;

  // setters for named parameter idiom
  Type & set__type(
    const uint8_t & _arg)
  {
    this->type = _arg;
    return *this;
  }
  Type & set__is_slave(
    const bool & _arg)
  {
    this->is_slave = _arg;
    return *this;
  }
  Type & set__is_quadruped(
    const bool & _arg)
  {
    this->is_quadruped = _arg;
    return *this;
  }
  Type & set__is_balance(
    const bool & _arg)
  {
    this->is_balance = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t MSG_TYPE_ACK =
    0u;
  static constexpr uint8_t MSG_TYPE_COMMAND =
    1u;
  static constexpr uint8_t MSG_TYPE_E_STOP =
    15u;

  // pointer types
  using RawPtr =
    ddt_msgs::srv::SendDockTransfer_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const ddt_msgs::srv::SendDockTransfer_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<ddt_msgs::srv::SendDockTransfer_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<ddt_msgs::srv::SendDockTransfer_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      ddt_msgs::srv::SendDockTransfer_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<ddt_msgs::srv::SendDockTransfer_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      ddt_msgs::srv::SendDockTransfer_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<ddt_msgs::srv::SendDockTransfer_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<ddt_msgs::srv::SendDockTransfer_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<ddt_msgs::srv::SendDockTransfer_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__ddt_msgs__srv__SendDockTransfer_Request
    std::shared_ptr<ddt_msgs::srv::SendDockTransfer_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__ddt_msgs__srv__SendDockTransfer_Request
    std::shared_ptr<ddt_msgs::srv::SendDockTransfer_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SendDockTransfer_Request_ & other) const
  {
    if (this->type != other.type) {
      return false;
    }
    if (this->is_slave != other.is_slave) {
      return false;
    }
    if (this->is_quadruped != other.is_quadruped) {
      return false;
    }
    if (this->is_balance != other.is_balance) {
      return false;
    }
    return true;
  }
  bool operator!=(const SendDockTransfer_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SendDockTransfer_Request_

// alias to use template instance with default allocator
using SendDockTransfer_Request =
  ddt_msgs::srv::SendDockTransfer_Request_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t SendDockTransfer_Request_<ContainerAllocator>::MSG_TYPE_ACK;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t SendDockTransfer_Request_<ContainerAllocator>::MSG_TYPE_COMMAND;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t SendDockTransfer_Request_<ContainerAllocator>::MSG_TYPE_E_STOP;
#endif  // __cplusplus < 201703L

}  // namespace srv

}  // namespace ddt_msgs


#ifndef _WIN32
# define DEPRECATED__ddt_msgs__srv__SendDockTransfer_Response __attribute__((deprecated))
#else
# define DEPRECATED__ddt_msgs__srv__SendDockTransfer_Response __declspec(deprecated)
#endif

namespace ddt_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct SendDockTransfer_Response_
{
  using Type = SendDockTransfer_Response_<ContainerAllocator>;

  explicit SendDockTransfer_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
    }
  }

  explicit SendDockTransfer_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : message(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
    }
  }

  // field types and members
  using _success_type =
    bool;
  _success_type success;
  using _message_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _message_type message;

  // setters for named parameter idiom
  Type & set__success(
    const bool & _arg)
  {
    this->success = _arg;
    return *this;
  }
  Type & set__message(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->message = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    ddt_msgs::srv::SendDockTransfer_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const ddt_msgs::srv::SendDockTransfer_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<ddt_msgs::srv::SendDockTransfer_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<ddt_msgs::srv::SendDockTransfer_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      ddt_msgs::srv::SendDockTransfer_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<ddt_msgs::srv::SendDockTransfer_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      ddt_msgs::srv::SendDockTransfer_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<ddt_msgs::srv::SendDockTransfer_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<ddt_msgs::srv::SendDockTransfer_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<ddt_msgs::srv::SendDockTransfer_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__ddt_msgs__srv__SendDockTransfer_Response
    std::shared_ptr<ddt_msgs::srv::SendDockTransfer_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__ddt_msgs__srv__SendDockTransfer_Response
    std::shared_ptr<ddt_msgs::srv::SendDockTransfer_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SendDockTransfer_Response_ & other) const
  {
    if (this->success != other.success) {
      return false;
    }
    if (this->message != other.message) {
      return false;
    }
    return true;
  }
  bool operator!=(const SendDockTransfer_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SendDockTransfer_Response_

// alias to use template instance with default allocator
using SendDockTransfer_Response =
  ddt_msgs::srv::SendDockTransfer_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace ddt_msgs

namespace ddt_msgs
{

namespace srv
{

struct SendDockTransfer
{
  using Request = ddt_msgs::srv::SendDockTransfer_Request;
  using Response = ddt_msgs::srv::SendDockTransfer_Response;
};

}  // namespace srv

}  // namespace ddt_msgs

#endif  // DDT_MSGS__SRV__DETAIL__SEND_DOCK_TRANSFER__STRUCT_HPP_
