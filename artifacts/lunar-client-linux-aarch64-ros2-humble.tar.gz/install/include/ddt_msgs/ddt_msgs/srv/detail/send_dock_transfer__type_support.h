// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from ddt_msgs:srv/SendDockTransfer.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__SRV__DETAIL__SEND_DOCK_TRANSFER__TYPE_SUPPORT_H_
#define DDT_MSGS__SRV__DETAIL__SEND_DOCK_TRANSFER__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "ddt_msgs/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_ddt_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  ddt_msgs,
  srv,
  SendDockTransfer_Request
)();

// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_ddt_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  ddt_msgs,
  srv,
  SendDockTransfer_Response
)();

#include "rosidl_runtime_c/service_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_ddt_msgs
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(
  rosidl_typesupport_c,
  ddt_msgs,
  srv,
  SendDockTransfer
)();

#ifdef __cplusplus
}
#endif

#endif  // DDT_MSGS__SRV__DETAIL__SEND_DOCK_TRANSFER__TYPE_SUPPORT_H_
