// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from ddt_msgs:srv/SendDockTransfer.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__SRV__DETAIL__SEND_DOCK_TRANSFER__TRAITS_HPP_
#define DDT_MSGS__SRV__DETAIL__SEND_DOCK_TRANSFER__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "ddt_msgs/srv/detail/send_dock_transfer__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace ddt_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const SendDockTransfer_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: type
  {
    out << "type: ";
    rosidl_generator_traits::value_to_yaml(msg.type, out);
    out << ", ";
  }

  // member: is_slave
  {
    out << "is_slave: ";
    rosidl_generator_traits::value_to_yaml(msg.is_slave, out);
    out << ", ";
  }

  // member: is_quadruped
  {
    out << "is_quadruped: ";
    rosidl_generator_traits::value_to_yaml(msg.is_quadruped, out);
    out << ", ";
  }

  // member: is_balance
  {
    out << "is_balance: ";
    rosidl_generator_traits::value_to_yaml(msg.is_balance, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SendDockTransfer_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "type: ";
    rosidl_generator_traits::value_to_yaml(msg.type, out);
    out << "\n";
  }

  // member: is_slave
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_slave: ";
    rosidl_generator_traits::value_to_yaml(msg.is_slave, out);
    out << "\n";
  }

  // member: is_quadruped
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_quadruped: ";
    rosidl_generator_traits::value_to_yaml(msg.is_quadruped, out);
    out << "\n";
  }

  // member: is_balance
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_balance: ";
    rosidl_generator_traits::value_to_yaml(msg.is_balance, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SendDockTransfer_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace ddt_msgs

namespace rosidl_generator_traits
{

[[deprecated("use ddt_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const ddt_msgs::srv::SendDockTransfer_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  ddt_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use ddt_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const ddt_msgs::srv::SendDockTransfer_Request & msg)
{
  return ddt_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<ddt_msgs::srv::SendDockTransfer_Request>()
{
  return "ddt_msgs::srv::SendDockTransfer_Request";
}

template<>
inline const char * name<ddt_msgs::srv::SendDockTransfer_Request>()
{
  return "ddt_msgs/srv/SendDockTransfer_Request";
}

template<>
struct has_fixed_size<ddt_msgs::srv::SendDockTransfer_Request>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<ddt_msgs::srv::SendDockTransfer_Request>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<ddt_msgs::srv::SendDockTransfer_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace ddt_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const SendDockTransfer_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: success
  {
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << ", ";
  }

  // member: message
  {
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SendDockTransfer_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: success
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << "\n";
  }

  // member: message
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SendDockTransfer_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace ddt_msgs

namespace rosidl_generator_traits
{

[[deprecated("use ddt_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const ddt_msgs::srv::SendDockTransfer_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  ddt_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use ddt_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const ddt_msgs::srv::SendDockTransfer_Response & msg)
{
  return ddt_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<ddt_msgs::srv::SendDockTransfer_Response>()
{
  return "ddt_msgs::srv::SendDockTransfer_Response";
}

template<>
inline const char * name<ddt_msgs::srv::SendDockTransfer_Response>()
{
  return "ddt_msgs/srv/SendDockTransfer_Response";
}

template<>
struct has_fixed_size<ddt_msgs::srv::SendDockTransfer_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<ddt_msgs::srv::SendDockTransfer_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<ddt_msgs::srv::SendDockTransfer_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<ddt_msgs::srv::SendDockTransfer>()
{
  return "ddt_msgs::srv::SendDockTransfer";
}

template<>
inline const char * name<ddt_msgs::srv::SendDockTransfer>()
{
  return "ddt_msgs/srv/SendDockTransfer";
}

template<>
struct has_fixed_size<ddt_msgs::srv::SendDockTransfer>
  : std::integral_constant<
    bool,
    has_fixed_size<ddt_msgs::srv::SendDockTransfer_Request>::value &&
    has_fixed_size<ddt_msgs::srv::SendDockTransfer_Response>::value
  >
{
};

template<>
struct has_bounded_size<ddt_msgs::srv::SendDockTransfer>
  : std::integral_constant<
    bool,
    has_bounded_size<ddt_msgs::srv::SendDockTransfer_Request>::value &&
    has_bounded_size<ddt_msgs::srv::SendDockTransfer_Response>::value
  >
{
};

template<>
struct is_service<ddt_msgs::srv::SendDockTransfer>
  : std::true_type
{
};

template<>
struct is_service_request<ddt_msgs::srv::SendDockTransfer_Request>
  : std::true_type
{
};

template<>
struct is_service_response<ddt_msgs::srv::SendDockTransfer_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // DDT_MSGS__SRV__DETAIL__SEND_DOCK_TRANSFER__TRAITS_HPP_
