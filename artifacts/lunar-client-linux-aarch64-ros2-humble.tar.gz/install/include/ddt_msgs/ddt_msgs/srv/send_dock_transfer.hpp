// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__SRV__SEND_DOCK_TRANSFER_HPP_
#define DDT_MSGS__SRV__SEND_DOCK_TRANSFER_HPP_

#include "ddt_msgs/srv/detail/send_dock_transfer__struct.hpp"
#include "ddt_msgs/srv/detail/send_dock_transfer__builder.hpp"
#include "ddt_msgs/srv/detail/send_dock_transfer__traits.hpp"
#include "ddt_msgs/srv/detail/send_dock_transfer__type_support.hpp"

#endif  // DDT_MSGS__SRV__SEND_DOCK_TRANSFER_HPP_
