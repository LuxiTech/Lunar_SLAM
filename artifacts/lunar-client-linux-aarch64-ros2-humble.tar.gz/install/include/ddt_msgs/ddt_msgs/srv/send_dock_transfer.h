// generated from rosidl_generator_c/resource/idl.h.em
// with input from ddt_msgs:srv/SendDockTransfer.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__SRV__SEND_DOCK_TRANSFER_H_
#define DDT_MSGS__SRV__SEND_DOCK_TRANSFER_H_

#include "ddt_msgs/srv/detail/send_dock_transfer__struct.h"
#include "ddt_msgs/srv/detail/send_dock_transfer__functions.h"
#include "ddt_msgs/srv/detail/send_dock_transfer__type_support.h"

#endif  // DDT_MSGS__SRV__SEND_DOCK_TRANSFER_H_
