// generated from rosidl_generator_c/resource/idl.h.em
// with input from ddt_msgs:msg/CentroidState.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__CENTROID_STATE_H_
#define DDT_MSGS__MSG__CENTROID_STATE_H_

#include "ddt_msgs/msg/detail/centroid_state__struct.h"
#include "ddt_msgs/msg/detail/centroid_state__functions.h"
#include "ddt_msgs/msg/detail/centroid_state__type_support.h"

#endif  // DDT_MSGS__MSG__CENTROID_STATE_H_
