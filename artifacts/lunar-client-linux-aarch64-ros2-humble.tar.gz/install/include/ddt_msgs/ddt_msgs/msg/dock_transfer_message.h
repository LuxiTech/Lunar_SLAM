// generated from rosidl_generator_c/resource/idl.h.em
// with input from ddt_msgs:msg/DockTransferMessage.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DOCK_TRANSFER_MESSAGE_H_
#define DDT_MSGS__MSG__DOCK_TRANSFER_MESSAGE_H_

#include "ddt_msgs/msg/detail/dock_transfer_message__struct.h"
#include "ddt_msgs/msg/detail/dock_transfer_message__functions.h"
#include "ddt_msgs/msg/detail/dock_transfer_message__type_support.h"

#endif  // DDT_MSGS__MSG__DOCK_TRANSFER_MESSAGE_H_
