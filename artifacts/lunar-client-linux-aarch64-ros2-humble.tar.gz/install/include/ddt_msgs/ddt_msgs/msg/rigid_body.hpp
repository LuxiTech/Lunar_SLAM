// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__RIGID_BODY_HPP_
#define DDT_MSGS__MSG__RIGID_BODY_HPP_

#include "ddt_msgs/msg/detail/rigid_body__struct.hpp"
#include "ddt_msgs/msg/detail/rigid_body__builder.hpp"
#include "ddt_msgs/msg/detail/rigid_body__traits.hpp"
#include "ddt_msgs/msg/detail/rigid_body__type_support.hpp"

#endif  // DDT_MSGS__MSG__RIGID_BODY_HPP_
