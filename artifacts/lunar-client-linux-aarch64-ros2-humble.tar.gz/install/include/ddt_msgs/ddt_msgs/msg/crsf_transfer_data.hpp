// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__CRSF_TRANSFER_DATA_HPP_
#define DDT_MSGS__MSG__CRSF_TRANSFER_DATA_HPP_

#include "ddt_msgs/msg/detail/crsf_transfer_data__struct.hpp"
#include "ddt_msgs/msg/detail/crsf_transfer_data__builder.hpp"
#include "ddt_msgs/msg/detail/crsf_transfer_data__traits.hpp"
#include "ddt_msgs/msg/detail/crsf_transfer_data__type_support.hpp"

#endif  // DDT_MSGS__MSG__CRSF_TRANSFER_DATA_HPP_
