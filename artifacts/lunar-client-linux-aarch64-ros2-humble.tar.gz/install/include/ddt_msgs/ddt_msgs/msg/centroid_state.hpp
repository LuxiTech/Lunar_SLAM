// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__CENTROID_STATE_HPP_
#define DDT_MSGS__MSG__CENTROID_STATE_HPP_

#include "ddt_msgs/msg/detail/centroid_state__struct.hpp"
#include "ddt_msgs/msg/detail/centroid_state__builder.hpp"
#include "ddt_msgs/msg/detail/centroid_state__traits.hpp"
#include "ddt_msgs/msg/detail/centroid_state__type_support.hpp"

#endif  // DDT_MSGS__MSG__CENTROID_STATE_HPP_
