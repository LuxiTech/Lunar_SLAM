// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DOCK_STATUS_HPP_
#define DDT_MSGS__MSG__DOCK_STATUS_HPP_

#include "ddt_msgs/msg/detail/dock_status__struct.hpp"
#include "ddt_msgs/msg/detail/dock_status__builder.hpp"
#include "ddt_msgs/msg/detail/dock_status__traits.hpp"
#include "ddt_msgs/msg/detail/dock_status__type_support.hpp"

#endif  // DDT_MSGS__MSG__DOCK_STATUS_HPP_
