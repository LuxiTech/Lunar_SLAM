// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from ddt_msgs:msg/PMSCommand.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__PMS_COMMAND__BUILDER_HPP_
#define DDT_MSGS__MSG__DETAIL__PMS_COMMAND__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "ddt_msgs/msg/detail/pms_command__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace ddt_msgs
{

namespace msg
{

namespace builder
{

class Init_PMSCommand_data
{
public:
  explicit Init_PMSCommand_data(::ddt_msgs::msg::PMSCommand & msg)
  : msg_(msg)
  {}
  ::ddt_msgs::msg::PMSCommand data(::ddt_msgs::msg::PMSCommand::_data_type arg)
  {
    msg_.data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ddt_msgs::msg::PMSCommand msg_;
};

class Init_PMSCommand_cmd
{
public:
  explicit Init_PMSCommand_cmd(::ddt_msgs::msg::PMSCommand & msg)
  : msg_(msg)
  {}
  Init_PMSCommand_data cmd(::ddt_msgs::msg::PMSCommand::_cmd_type arg)
  {
    msg_.cmd = std::move(arg);
    return Init_PMSCommand_data(msg_);
  }

private:
  ::ddt_msgs::msg::PMSCommand msg_;
};

class Init_PMSCommand_header
{
public:
  Init_PMSCommand_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PMSCommand_cmd header(::ddt_msgs::msg::PMSCommand::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_PMSCommand_cmd(msg_);
  }

private:
  ::ddt_msgs::msg::PMSCommand msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::ddt_msgs::msg::PMSCommand>()
{
  return ddt_msgs::msg::builder::Init_PMSCommand_header();
}

}  // namespace ddt_msgs

#endif  // DDT_MSGS__MSG__DETAIL__PMS_COMMAND__BUILDER_HPP_
