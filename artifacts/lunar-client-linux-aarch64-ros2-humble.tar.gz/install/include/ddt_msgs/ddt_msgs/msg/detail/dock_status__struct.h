// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from ddt_msgs:msg/DockStatus.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__DOCK_STATUS__STRUCT_H_
#define DDT_MSGS__MSG__DETAIL__DOCK_STATUS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/DockStatus in the package ddt_msgs.
typedef struct ddt_msgs__msg__DockStatus
{
  std_msgs__msg__Header header;
  bool present;
  bool slave;
  bool connect;
} ddt_msgs__msg__DockStatus;

// Struct for a sequence of ddt_msgs__msg__DockStatus.
typedef struct ddt_msgs__msg__DockStatus__Sequence
{
  ddt_msgs__msg__DockStatus * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} ddt_msgs__msg__DockStatus__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DDT_MSGS__MSG__DETAIL__DOCK_STATUS__STRUCT_H_
