// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from ddt_msgs:msg/CentroidState.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__CENTROID_STATE__BUILDER_HPP_
#define DDT_MSGS__MSG__DETAIL__CENTROID_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "ddt_msgs/msg/detail/centroid_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace ddt_msgs
{

namespace msg
{

namespace builder
{

class Init_CentroidState_set_tilt
{
public:
  explicit Init_CentroidState_set_tilt(::ddt_msgs::msg::CentroidState & msg)
  : msg_(msg)
  {}
  ::ddt_msgs::msg::CentroidState set_tilt(::ddt_msgs::msg::CentroidState::_set_tilt_type arg)
  {
    msg_.set_tilt = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ddt_msgs::msg::CentroidState msg_;
};

class Init_CentroidState_whole_body_com
{
public:
  explicit Init_CentroidState_whole_body_com(::ddt_msgs::msg::CentroidState & msg)
  : msg_(msg)
  {}
  Init_CentroidState_set_tilt whole_body_com(::ddt_msgs::msg::CentroidState::_whole_body_com_type arg)
  {
    msg_.whole_body_com = std::move(arg);
    return Init_CentroidState_set_tilt(msg_);
  }

private:
  ::ddt_msgs::msg::CentroidState msg_;
};

class Init_CentroidState_header
{
public:
  Init_CentroidState_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CentroidState_whole_body_com header(::ddt_msgs::msg::CentroidState::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_CentroidState_whole_body_com(msg_);
  }

private:
  ::ddt_msgs::msg::CentroidState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::ddt_msgs::msg::CentroidState>()
{
  return ddt_msgs::msg::builder::Init_CentroidState_header();
}

}  // namespace ddt_msgs

#endif  // DDT_MSGS__MSG__DETAIL__CENTROID_STATE__BUILDER_HPP_
