// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from ddt_msgs:msg/DockTransferMessage.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__DOCK_TRANSFER_MESSAGE__STRUCT_HPP_
#define DDT_MSGS__MSG__DETAIL__DOCK_TRANSFER_MESSAGE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__ddt_msgs__msg__DockTransferMessage __attribute__((deprecated))
#else
# define DEPRECATED__ddt_msgs__msg__DockTransferMessage __declspec(deprecated)
#endif

namespace ddt_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct DockTransferMessage_
{
  using Type = DockTransferMessage_<ContainerAllocator>;

  explicit DockTransferMessage_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->type = 0;
      this->is_slave = false;
      this->is_quadruped = false;
      this->is_balance = false;
      this->error = false;
    }
  }

  explicit DockTransferMessage_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->type = 0;
      this->is_slave = false;
      this->is_quadruped = false;
      this->is_balance = false;
      this->error = false;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _type_type =
    uint8_t;
  _type_type type;
  using _is_slave_type =
    bool;
  _is_slave_type is_slave;
  using _is_quadruped_type =
    bool;
  _is_quadruped_type is_quadruped;
  using _is_balance_type =
    bool;
  _is_balance_type is_balance;
  using _error_type =
    bool;
  _error_type error;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__type(
    const uint8_t & _arg)
  {
    this->type = _arg;
    return *this;
  }
  Type & set__is_slave(
    const bool & _arg)
  {
    this->is_slave = _arg;
    return *this;
  }
  Type & set__is_quadruped(
    const bool & _arg)
  {
    this->is_quadruped = _arg;
    return *this;
  }
  Type & set__is_balance(
    const bool & _arg)
  {
    this->is_balance = _arg;
    return *this;
  }
  Type & set__error(
    const bool & _arg)
  {
    this->error = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t MSG_TYPE_ACK =
    0u;
  static constexpr uint8_t MSG_TYPE_COMMAND =
    1u;
  static constexpr uint8_t MSG_TYPE_E_STOP =
    15u;

  // pointer types
  using RawPtr =
    ddt_msgs::msg::DockTransferMessage_<ContainerAllocator> *;
  using ConstRawPtr =
    const ddt_msgs::msg::DockTransferMessage_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<ddt_msgs::msg::DockTransferMessage_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<ddt_msgs::msg::DockTransferMessage_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      ddt_msgs::msg::DockTransferMessage_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<ddt_msgs::msg::DockTransferMessage_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      ddt_msgs::msg::DockTransferMessage_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<ddt_msgs::msg::DockTransferMessage_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<ddt_msgs::msg::DockTransferMessage_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<ddt_msgs::msg::DockTransferMessage_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__ddt_msgs__msg__DockTransferMessage
    std::shared_ptr<ddt_msgs::msg::DockTransferMessage_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__ddt_msgs__msg__DockTransferMessage
    std::shared_ptr<ddt_msgs::msg::DockTransferMessage_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const DockTransferMessage_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->type != other.type) {
      return false;
    }
    if (this->is_slave != other.is_slave) {
      return false;
    }
    if (this->is_quadruped != other.is_quadruped) {
      return false;
    }
    if (this->is_balance != other.is_balance) {
      return false;
    }
    if (this->error != other.error) {
      return false;
    }
    return true;
  }
  bool operator!=(const DockTransferMessage_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct DockTransferMessage_

// alias to use template instance with default allocator
using DockTransferMessage =
  ddt_msgs::msg::DockTransferMessage_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t DockTransferMessage_<ContainerAllocator>::MSG_TYPE_ACK;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t DockTransferMessage_<ContainerAllocator>::MSG_TYPE_COMMAND;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t DockTransferMessage_<ContainerAllocator>::MSG_TYPE_E_STOP;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace ddt_msgs

#endif  // DDT_MSGS__MSG__DETAIL__DOCK_TRANSFER_MESSAGE__STRUCT_HPP_
