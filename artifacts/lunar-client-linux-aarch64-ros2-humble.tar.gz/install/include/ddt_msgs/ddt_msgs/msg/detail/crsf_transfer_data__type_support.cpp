// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from ddt_msgs:msg/CrsfTransferData.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "ddt_msgs/msg/detail/crsf_transfer_data__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace ddt_msgs
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void CrsfTransferData_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) ddt_msgs::msg::CrsfTransferData(_init);
}

void CrsfTransferData_fini_function(void * message_memory)
{
  auto typed_message = static_cast<ddt_msgs::msg::CrsfTransferData *>(message_memory);
  typed_message->~CrsfTransferData();
}

size_t size_function__CrsfTransferData__buttons(const void * untyped_member)
{
  (void)untyped_member;
  return 16;
}

const void * get_const_function__CrsfTransferData__buttons(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<uint8_t, 16> *>(untyped_member);
  return &member[index];
}

void * get_function__CrsfTransferData__buttons(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<uint8_t, 16> *>(untyped_member);
  return &member[index];
}

void fetch_function__CrsfTransferData__buttons(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const uint8_t *>(
    get_const_function__CrsfTransferData__buttons(untyped_member, index));
  auto & value = *reinterpret_cast<uint8_t *>(untyped_value);
  value = item;
}

void assign_function__CrsfTransferData__buttons(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<uint8_t *>(
    get_function__CrsfTransferData__buttons(untyped_member, index));
  const auto & value = *reinterpret_cast<const uint8_t *>(untyped_value);
  item = value;
}

size_t size_function__CrsfTransferData__bat(const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * get_const_function__CrsfTransferData__bat(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::array<uint8_t, 2> *>(untyped_member);
  return &member[index];
}

void * get_function__CrsfTransferData__bat(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::array<uint8_t, 2> *>(untyped_member);
  return &member[index];
}

void fetch_function__CrsfTransferData__bat(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const uint8_t *>(
    get_const_function__CrsfTransferData__bat(untyped_member, index));
  auto & value = *reinterpret_cast<uint8_t *>(untyped_value);
  value = item;
}

void assign_function__CrsfTransferData__bat(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<uint8_t *>(
    get_function__CrsfTransferData__bat(untyped_member, index));
  const auto & value = *reinterpret_cast<const uint8_t *>(untyped_value);
  item = value;
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember CrsfTransferData_message_member_array[5] = {
  {
    "header",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<std_msgs::msg::Header>(),  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(ddt_msgs::msg::CrsfTransferData, header),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "version",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(ddt_msgs::msg::CrsfTransferData, version),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "error_code",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(ddt_msgs::msg::CrsfTransferData, error_code),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "buttons",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    16,  // array size
    false,  // is upper bound
    offsetof(ddt_msgs::msg::CrsfTransferData, buttons),  // bytes offset in struct
    nullptr,  // default value
    size_function__CrsfTransferData__buttons,  // size() function pointer
    get_const_function__CrsfTransferData__buttons,  // get_const(index) function pointer
    get_function__CrsfTransferData__buttons,  // get(index) function pointer
    fetch_function__CrsfTransferData__buttons,  // fetch(index, &value) function pointer
    assign_function__CrsfTransferData__buttons,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "bat",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(ddt_msgs::msg::CrsfTransferData, bat),  // bytes offset in struct
    nullptr,  // default value
    size_function__CrsfTransferData__bat,  // size() function pointer
    get_const_function__CrsfTransferData__bat,  // get_const(index) function pointer
    get_function__CrsfTransferData__bat,  // get(index) function pointer
    fetch_function__CrsfTransferData__bat,  // fetch(index, &value) function pointer
    assign_function__CrsfTransferData__bat,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers CrsfTransferData_message_members = {
  "ddt_msgs::msg",  // message namespace
  "CrsfTransferData",  // message name
  5,  // number of fields
  sizeof(ddt_msgs::msg::CrsfTransferData),
  CrsfTransferData_message_member_array,  // message members
  CrsfTransferData_init_function,  // function to initialize message memory (memory has to be allocated)
  CrsfTransferData_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t CrsfTransferData_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &CrsfTransferData_message_members,
  get_message_typesupport_handle_function,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace ddt_msgs


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<ddt_msgs::msg::CrsfTransferData>()
{
  return &::ddt_msgs::msg::rosidl_typesupport_introspection_cpp::CrsfTransferData_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, ddt_msgs, msg, CrsfTransferData)() {
  return &::ddt_msgs::msg::rosidl_typesupport_introspection_cpp::CrsfTransferData_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
