﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from ddt_msgs:msg/UserCommand.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__USER_COMMAND__STRUCT_H_
#define DDT_MSGS__MSG__DETAIL__USER_COMMAND__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'fsm_mode'
#include "rosidl_runtime_c/string.h"
// Member 'pose'
#include "geometry_msgs/msg/detail/pose__struct.h"
// Member 'twist'
#include "geometry_msgs/msg/detail/twist__struct.h"

/// Struct defined in msg/UserCommand in the package ddt_msgs.
/**
  * Command manager send msg to locomotion unit.
 */
typedef struct ddt_msgs__msg__UserCommand
{
  std_msgs__msg__Header header;
  /// robot availible fsm: transform_up，transform_down，loco，joint_pd，car，rl_*(1, 2, 3)
  rosidl_runtime_c__String fsm_mode;
  /// Robot body pose
  geometry_msgs__msg__Pose pose;
  /// Speed control of robot chassis
  geometry_msgs__msg__Twist twist;
} ddt_msgs__msg__UserCommand;

// Struct for a sequence of ddt_msgs__msg__UserCommand.
typedef struct ddt_msgs__msg__UserCommand__Sequence
{
  ddt_msgs__msg__UserCommand * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} ddt_msgs__msg__UserCommand__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DDT_MSGS__MSG__DETAIL__USER_COMMAND__STRUCT_H_
