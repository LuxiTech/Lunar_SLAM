// generated from rosidl_typesupport_introspection_cpp/resource/idl__rosidl_typesupport_introspection_cpp.h.em
// with input from ddt_msgs:msg/JointControlCommand.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__JOINT_CONTROL_COMMAND__ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_HPP_
#define DDT_MSGS__MSG__DETAIL__JOINT_CONTROL_COMMAND__ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_HPP_


#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

// TODO(dirk-thomas) these visibility macros should be message package specific
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, ddt_msgs, msg, JointControlCommand)();

#ifdef __cplusplus
}
#endif

#endif  // DDT_MSGS__MSG__DETAIL__JOINT_CONTROL_COMMAND__ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_HPP_
