// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from ddt_msgs:msg/DockTransferMessage.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__DOCK_TRANSFER_MESSAGE__BUILDER_HPP_
#define DDT_MSGS__MSG__DETAIL__DOCK_TRANSFER_MESSAGE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "ddt_msgs/msg/detail/dock_transfer_message__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace ddt_msgs
{

namespace msg
{

namespace builder
{

class Init_DockTransferMessage_error
{
public:
  explicit Init_DockTransferMessage_error(::ddt_msgs::msg::DockTransferMessage & msg)
  : msg_(msg)
  {}
  ::ddt_msgs::msg::DockTransferMessage error(::ddt_msgs::msg::DockTransferMessage::_error_type arg)
  {
    msg_.error = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ddt_msgs::msg::DockTransferMessage msg_;
};

class Init_DockTransferMessage_is_balance
{
public:
  explicit Init_DockTransferMessage_is_balance(::ddt_msgs::msg::DockTransferMessage & msg)
  : msg_(msg)
  {}
  Init_DockTransferMessage_error is_balance(::ddt_msgs::msg::DockTransferMessage::_is_balance_type arg)
  {
    msg_.is_balance = std::move(arg);
    return Init_DockTransferMessage_error(msg_);
  }

private:
  ::ddt_msgs::msg::DockTransferMessage msg_;
};

class Init_DockTransferMessage_is_quadruped
{
public:
  explicit Init_DockTransferMessage_is_quadruped(::ddt_msgs::msg::DockTransferMessage & msg)
  : msg_(msg)
  {}
  Init_DockTransferMessage_is_balance is_quadruped(::ddt_msgs::msg::DockTransferMessage::_is_quadruped_type arg)
  {
    msg_.is_quadruped = std::move(arg);
    return Init_DockTransferMessage_is_balance(msg_);
  }

private:
  ::ddt_msgs::msg::DockTransferMessage msg_;
};

class Init_DockTransferMessage_is_slave
{
public:
  explicit Init_DockTransferMessage_is_slave(::ddt_msgs::msg::DockTransferMessage & msg)
  : msg_(msg)
  {}
  Init_DockTransferMessage_is_quadruped is_slave(::ddt_msgs::msg::DockTransferMessage::_is_slave_type arg)
  {
    msg_.is_slave = std::move(arg);
    return Init_DockTransferMessage_is_quadruped(msg_);
  }

private:
  ::ddt_msgs::msg::DockTransferMessage msg_;
};

class Init_DockTransferMessage_type
{
public:
  explicit Init_DockTransferMessage_type(::ddt_msgs::msg::DockTransferMessage & msg)
  : msg_(msg)
  {}
  Init_DockTransferMessage_is_slave type(::ddt_msgs::msg::DockTransferMessage::_type_type arg)
  {
    msg_.type = std::move(arg);
    return Init_DockTransferMessage_is_slave(msg_);
  }

private:
  ::ddt_msgs::msg::DockTransferMessage msg_;
};

class Init_DockTransferMessage_header
{
public:
  Init_DockTransferMessage_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DockTransferMessage_type header(::ddt_msgs::msg::DockTransferMessage::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_DockTransferMessage_type(msg_);
  }

private:
  ::ddt_msgs::msg::DockTransferMessage msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::ddt_msgs::msg::DockTransferMessage>()
{
  return ddt_msgs::msg::builder::Init_DockTransferMessage_header();
}

}  // namespace ddt_msgs

#endif  // DDT_MSGS__MSG__DETAIL__DOCK_TRANSFER_MESSAGE__BUILDER_HPP_
