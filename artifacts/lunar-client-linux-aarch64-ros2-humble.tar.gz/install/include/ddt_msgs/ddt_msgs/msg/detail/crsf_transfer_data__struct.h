// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from ddt_msgs:msg/CrsfTransferData.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__CRSF_TRANSFER_DATA__STRUCT_H_
#define DDT_MSGS__MSG__DETAIL__CRSF_TRANSFER_DATA__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/CrsfTransferData in the package ddt_msgs.
/**
  * crsf transfer data
 */
typedef struct ddt_msgs__msg__CrsfTransferData
{
  std_msgs__msg__Header header;
  uint32_t version;
  uint32_t error_code;
  uint8_t buttons[16];
  uint8_t bat[2];
} ddt_msgs__msg__CrsfTransferData;

// Struct for a sequence of ddt_msgs__msg__CrsfTransferData.
typedef struct ddt_msgs__msg__CrsfTransferData__Sequence
{
  ddt_msgs__msg__CrsfTransferData * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} ddt_msgs__msg__CrsfTransferData__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DDT_MSGS__MSG__DETAIL__CRSF_TRANSFER_DATA__STRUCT_H_
