// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from ddt_msgs:msg/JointControlCommand.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__JOINT_CONTROL_COMMAND__STRUCT_HPP_
#define DDT_MSGS__MSG__DETAIL__JOINT_CONTROL_COMMAND__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__ddt_msgs__msg__JointControlCommand __attribute__((deprecated))
#else
# define DEPRECATED__ddt_msgs__msg__JointControlCommand __declspec(deprecated)
#endif

namespace ddt_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct JointControlCommand_
{
  using Type = JointControlCommand_<ContainerAllocator>;

  explicit JointControlCommand_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    (void)_init;
  }

  explicit JointControlCommand_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _name_type =
    std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>>;
  _name_type name;
  using _kp_type =
    std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>>;
  _kp_type kp;
  using _kd_type =
    std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>>;
  _kd_type kd;
  using _position_type =
    std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>>;
  _position_type position;
  using _velocity_type =
    std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>>;
  _velocity_type velocity;
  using _effort_type =
    std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>>;
  _effort_type effort;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__name(
    const std::vector<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>>> & _arg)
  {
    this->name = _arg;
    return *this;
  }
  Type & set__kp(
    const std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>> & _arg)
  {
    this->kp = _arg;
    return *this;
  }
  Type & set__kd(
    const std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>> & _arg)
  {
    this->kd = _arg;
    return *this;
  }
  Type & set__position(
    const std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>> & _arg)
  {
    this->position = _arg;
    return *this;
  }
  Type & set__velocity(
    const std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>> & _arg)
  {
    this->velocity = _arg;
    return *this;
  }
  Type & set__effort(
    const std::vector<double, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<double>> & _arg)
  {
    this->effort = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    ddt_msgs::msg::JointControlCommand_<ContainerAllocator> *;
  using ConstRawPtr =
    const ddt_msgs::msg::JointControlCommand_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<ddt_msgs::msg::JointControlCommand_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<ddt_msgs::msg::JointControlCommand_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      ddt_msgs::msg::JointControlCommand_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<ddt_msgs::msg::JointControlCommand_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      ddt_msgs::msg::JointControlCommand_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<ddt_msgs::msg::JointControlCommand_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<ddt_msgs::msg::JointControlCommand_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<ddt_msgs::msg::JointControlCommand_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__ddt_msgs__msg__JointControlCommand
    std::shared_ptr<ddt_msgs::msg::JointControlCommand_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__ddt_msgs__msg__JointControlCommand
    std::shared_ptr<ddt_msgs::msg::JointControlCommand_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const JointControlCommand_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->name != other.name) {
      return false;
    }
    if (this->kp != other.kp) {
      return false;
    }
    if (this->kd != other.kd) {
      return false;
    }
    if (this->position != other.position) {
      return false;
    }
    if (this->velocity != other.velocity) {
      return false;
    }
    if (this->effort != other.effort) {
      return false;
    }
    return true;
  }
  bool operator!=(const JointControlCommand_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct JointControlCommand_

// alias to use template instance with default allocator
using JointControlCommand =
  ddt_msgs::msg::JointControlCommand_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace ddt_msgs

#endif  // DDT_MSGS__MSG__DETAIL__JOINT_CONTROL_COMMAND__STRUCT_HPP_
