// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from ddt_msgs:msg/JointControlCommand.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "ddt_msgs/msg/detail/joint_control_command__rosidl_typesupport_introspection_c.h"
#include "ddt_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "ddt_msgs/msg/detail/joint_control_command__functions.h"
#include "ddt_msgs/msg/detail/joint_control_command__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"
// Member `name`
#include "rosidl_runtime_c/string_functions.h"
// Member `kp`
// Member `kd`
// Member `position`
// Member `velocity`
// Member `effort`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

#ifdef __cplusplus
extern "C"
{
#endif

void ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__JointControlCommand_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  ddt_msgs__msg__JointControlCommand__init(message_memory);
}

void ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__JointControlCommand_fini_function(void * message_memory)
{
  ddt_msgs__msg__JointControlCommand__fini(message_memory);
}

size_t ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__size_function__JointControlCommand__name(
  const void * untyped_member)
{
  const rosidl_runtime_c__String__Sequence * member =
    (const rosidl_runtime_c__String__Sequence *)(untyped_member);
  return member->size;
}

const void * ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_const_function__JointControlCommand__name(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__String__Sequence * member =
    (const rosidl_runtime_c__String__Sequence *)(untyped_member);
  return &member->data[index];
}

void * ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_function__JointControlCommand__name(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__String__Sequence * member =
    (rosidl_runtime_c__String__Sequence *)(untyped_member);
  return &member->data[index];
}

void ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__fetch_function__JointControlCommand__name(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const rosidl_runtime_c__String * item =
    ((const rosidl_runtime_c__String *)
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_const_function__JointControlCommand__name(untyped_member, index));
  rosidl_runtime_c__String * value =
    (rosidl_runtime_c__String *)(untyped_value);
  *value = *item;
}

void ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__assign_function__JointControlCommand__name(
  void * untyped_member, size_t index, const void * untyped_value)
{
  rosidl_runtime_c__String * item =
    ((rosidl_runtime_c__String *)
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_function__JointControlCommand__name(untyped_member, index));
  const rosidl_runtime_c__String * value =
    (const rosidl_runtime_c__String *)(untyped_value);
  *item = *value;
}

bool ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__resize_function__JointControlCommand__name(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__String__Sequence * member =
    (rosidl_runtime_c__String__Sequence *)(untyped_member);
  rosidl_runtime_c__String__Sequence__fini(member);
  return rosidl_runtime_c__String__Sequence__init(member, size);
}

size_t ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__size_function__JointControlCommand__kp(
  const void * untyped_member)
{
  const rosidl_runtime_c__double__Sequence * member =
    (const rosidl_runtime_c__double__Sequence *)(untyped_member);
  return member->size;
}

const void * ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_const_function__JointControlCommand__kp(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__double__Sequence * member =
    (const rosidl_runtime_c__double__Sequence *)(untyped_member);
  return &member->data[index];
}

void * ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_function__JointControlCommand__kp(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__double__Sequence * member =
    (rosidl_runtime_c__double__Sequence *)(untyped_member);
  return &member->data[index];
}

void ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__fetch_function__JointControlCommand__kp(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const double * item =
    ((const double *)
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_const_function__JointControlCommand__kp(untyped_member, index));
  double * value =
    (double *)(untyped_value);
  *value = *item;
}

void ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__assign_function__JointControlCommand__kp(
  void * untyped_member, size_t index, const void * untyped_value)
{
  double * item =
    ((double *)
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_function__JointControlCommand__kp(untyped_member, index));
  const double * value =
    (const double *)(untyped_value);
  *item = *value;
}

bool ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__resize_function__JointControlCommand__kp(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__double__Sequence * member =
    (rosidl_runtime_c__double__Sequence *)(untyped_member);
  rosidl_runtime_c__double__Sequence__fini(member);
  return rosidl_runtime_c__double__Sequence__init(member, size);
}

size_t ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__size_function__JointControlCommand__kd(
  const void * untyped_member)
{
  const rosidl_runtime_c__double__Sequence * member =
    (const rosidl_runtime_c__double__Sequence *)(untyped_member);
  return member->size;
}

const void * ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_const_function__JointControlCommand__kd(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__double__Sequence * member =
    (const rosidl_runtime_c__double__Sequence *)(untyped_member);
  return &member->data[index];
}

void * ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_function__JointControlCommand__kd(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__double__Sequence * member =
    (rosidl_runtime_c__double__Sequence *)(untyped_member);
  return &member->data[index];
}

void ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__fetch_function__JointControlCommand__kd(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const double * item =
    ((const double *)
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_const_function__JointControlCommand__kd(untyped_member, index));
  double * value =
    (double *)(untyped_value);
  *value = *item;
}

void ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__assign_function__JointControlCommand__kd(
  void * untyped_member, size_t index, const void * untyped_value)
{
  double * item =
    ((double *)
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_function__JointControlCommand__kd(untyped_member, index));
  const double * value =
    (const double *)(untyped_value);
  *item = *value;
}

bool ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__resize_function__JointControlCommand__kd(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__double__Sequence * member =
    (rosidl_runtime_c__double__Sequence *)(untyped_member);
  rosidl_runtime_c__double__Sequence__fini(member);
  return rosidl_runtime_c__double__Sequence__init(member, size);
}

size_t ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__size_function__JointControlCommand__position(
  const void * untyped_member)
{
  const rosidl_runtime_c__double__Sequence * member =
    (const rosidl_runtime_c__double__Sequence *)(untyped_member);
  return member->size;
}

const void * ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_const_function__JointControlCommand__position(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__double__Sequence * member =
    (const rosidl_runtime_c__double__Sequence *)(untyped_member);
  return &member->data[index];
}

void * ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_function__JointControlCommand__position(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__double__Sequence * member =
    (rosidl_runtime_c__double__Sequence *)(untyped_member);
  return &member->data[index];
}

void ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__fetch_function__JointControlCommand__position(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const double * item =
    ((const double *)
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_const_function__JointControlCommand__position(untyped_member, index));
  double * value =
    (double *)(untyped_value);
  *value = *item;
}

void ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__assign_function__JointControlCommand__position(
  void * untyped_member, size_t index, const void * untyped_value)
{
  double * item =
    ((double *)
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_function__JointControlCommand__position(untyped_member, index));
  const double * value =
    (const double *)(untyped_value);
  *item = *value;
}

bool ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__resize_function__JointControlCommand__position(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__double__Sequence * member =
    (rosidl_runtime_c__double__Sequence *)(untyped_member);
  rosidl_runtime_c__double__Sequence__fini(member);
  return rosidl_runtime_c__double__Sequence__init(member, size);
}

size_t ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__size_function__JointControlCommand__velocity(
  const void * untyped_member)
{
  const rosidl_runtime_c__double__Sequence * member =
    (const rosidl_runtime_c__double__Sequence *)(untyped_member);
  return member->size;
}

const void * ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_const_function__JointControlCommand__velocity(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__double__Sequence * member =
    (const rosidl_runtime_c__double__Sequence *)(untyped_member);
  return &member->data[index];
}

void * ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_function__JointControlCommand__velocity(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__double__Sequence * member =
    (rosidl_runtime_c__double__Sequence *)(untyped_member);
  return &member->data[index];
}

void ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__fetch_function__JointControlCommand__velocity(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const double * item =
    ((const double *)
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_const_function__JointControlCommand__velocity(untyped_member, index));
  double * value =
    (double *)(untyped_value);
  *value = *item;
}

void ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__assign_function__JointControlCommand__velocity(
  void * untyped_member, size_t index, const void * untyped_value)
{
  double * item =
    ((double *)
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_function__JointControlCommand__velocity(untyped_member, index));
  const double * value =
    (const double *)(untyped_value);
  *item = *value;
}

bool ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__resize_function__JointControlCommand__velocity(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__double__Sequence * member =
    (rosidl_runtime_c__double__Sequence *)(untyped_member);
  rosidl_runtime_c__double__Sequence__fini(member);
  return rosidl_runtime_c__double__Sequence__init(member, size);
}

size_t ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__size_function__JointControlCommand__effort(
  const void * untyped_member)
{
  const rosidl_runtime_c__double__Sequence * member =
    (const rosidl_runtime_c__double__Sequence *)(untyped_member);
  return member->size;
}

const void * ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_const_function__JointControlCommand__effort(
  const void * untyped_member, size_t index)
{
  const rosidl_runtime_c__double__Sequence * member =
    (const rosidl_runtime_c__double__Sequence *)(untyped_member);
  return &member->data[index];
}

void * ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_function__JointControlCommand__effort(
  void * untyped_member, size_t index)
{
  rosidl_runtime_c__double__Sequence * member =
    (rosidl_runtime_c__double__Sequence *)(untyped_member);
  return &member->data[index];
}

void ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__fetch_function__JointControlCommand__effort(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const double * item =
    ((const double *)
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_const_function__JointControlCommand__effort(untyped_member, index));
  double * value =
    (double *)(untyped_value);
  *value = *item;
}

void ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__assign_function__JointControlCommand__effort(
  void * untyped_member, size_t index, const void * untyped_value)
{
  double * item =
    ((double *)
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_function__JointControlCommand__effort(untyped_member, index));
  const double * value =
    (const double *)(untyped_value);
  *item = *value;
}

bool ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__resize_function__JointControlCommand__effort(
  void * untyped_member, size_t size)
{
  rosidl_runtime_c__double__Sequence * member =
    (rosidl_runtime_c__double__Sequence *)(untyped_member);
  rosidl_runtime_c__double__Sequence__fini(member);
  return rosidl_runtime_c__double__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__JointControlCommand_message_member_array[7] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(ddt_msgs__msg__JointControlCommand, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "name",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(ddt_msgs__msg__JointControlCommand, name),  // bytes offset in struct
    NULL,  // default value
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__size_function__JointControlCommand__name,  // size() function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_const_function__JointControlCommand__name,  // get_const(index) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_function__JointControlCommand__name,  // get(index) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__fetch_function__JointControlCommand__name,  // fetch(index, &value) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__assign_function__JointControlCommand__name,  // assign(index, value) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__resize_function__JointControlCommand__name  // resize(index) function pointer
  },
  {
    "kp",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(ddt_msgs__msg__JointControlCommand, kp),  // bytes offset in struct
    NULL,  // default value
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__size_function__JointControlCommand__kp,  // size() function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_const_function__JointControlCommand__kp,  // get_const(index) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_function__JointControlCommand__kp,  // get(index) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__fetch_function__JointControlCommand__kp,  // fetch(index, &value) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__assign_function__JointControlCommand__kp,  // assign(index, value) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__resize_function__JointControlCommand__kp  // resize(index) function pointer
  },
  {
    "kd",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(ddt_msgs__msg__JointControlCommand, kd),  // bytes offset in struct
    NULL,  // default value
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__size_function__JointControlCommand__kd,  // size() function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_const_function__JointControlCommand__kd,  // get_const(index) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_function__JointControlCommand__kd,  // get(index) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__fetch_function__JointControlCommand__kd,  // fetch(index, &value) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__assign_function__JointControlCommand__kd,  // assign(index, value) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__resize_function__JointControlCommand__kd  // resize(index) function pointer
  },
  {
    "position",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(ddt_msgs__msg__JointControlCommand, position),  // bytes offset in struct
    NULL,  // default value
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__size_function__JointControlCommand__position,  // size() function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_const_function__JointControlCommand__position,  // get_const(index) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_function__JointControlCommand__position,  // get(index) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__fetch_function__JointControlCommand__position,  // fetch(index, &value) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__assign_function__JointControlCommand__position,  // assign(index, value) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__resize_function__JointControlCommand__position  // resize(index) function pointer
  },
  {
    "velocity",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(ddt_msgs__msg__JointControlCommand, velocity),  // bytes offset in struct
    NULL,  // default value
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__size_function__JointControlCommand__velocity,  // size() function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_const_function__JointControlCommand__velocity,  // get_const(index) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_function__JointControlCommand__velocity,  // get(index) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__fetch_function__JointControlCommand__velocity,  // fetch(index, &value) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__assign_function__JointControlCommand__velocity,  // assign(index, value) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__resize_function__JointControlCommand__velocity  // resize(index) function pointer
  },
  {
    "effort",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_DOUBLE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(ddt_msgs__msg__JointControlCommand, effort),  // bytes offset in struct
    NULL,  // default value
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__size_function__JointControlCommand__effort,  // size() function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_const_function__JointControlCommand__effort,  // get_const(index) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__get_function__JointControlCommand__effort,  // get(index) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__fetch_function__JointControlCommand__effort,  // fetch(index, &value) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__assign_function__JointControlCommand__effort,  // assign(index, value) function pointer
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__resize_function__JointControlCommand__effort  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__JointControlCommand_message_members = {
  "ddt_msgs__msg",  // message namespace
  "JointControlCommand",  // message name
  7,  // number of fields
  sizeof(ddt_msgs__msg__JointControlCommand),
  ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__JointControlCommand_message_member_array,  // message members
  ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__JointControlCommand_init_function,  // function to initialize message memory (memory has to be allocated)
  ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__JointControlCommand_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__JointControlCommand_message_type_support_handle = {
  0,
  &ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__JointControlCommand_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_ddt_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, ddt_msgs, msg, JointControlCommand)() {
  ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__JointControlCommand_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  if (!ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__JointControlCommand_message_type_support_handle.typesupport_identifier) {
    ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__JointControlCommand_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &ddt_msgs__msg__JointControlCommand__rosidl_typesupport_introspection_c__JointControlCommand_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
