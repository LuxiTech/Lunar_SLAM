// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from ddt_msgs:msg/CentroidState.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__CENTROID_STATE__TRAITS_HPP_
#define DDT_MSGS__MSG__DETAIL__CENTROID_STATE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "ddt_msgs/msg/detail/centroid_state__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'whole_body_com'
#include "geometry_msgs/msg/detail/vector3__traits.hpp"

namespace ddt_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const CentroidState & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: whole_body_com
  {
    out << "whole_body_com: ";
    to_flow_style_yaml(msg.whole_body_com, out);
    out << ", ";
  }

  // member: set_tilt
  {
    out << "set_tilt: ";
    rosidl_generator_traits::value_to_yaml(msg.set_tilt, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const CentroidState & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: whole_body_com
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "whole_body_com:\n";
    to_block_style_yaml(msg.whole_body_com, out, indentation + 2);
  }

  // member: set_tilt
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "set_tilt: ";
    rosidl_generator_traits::value_to_yaml(msg.set_tilt, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const CentroidState & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace ddt_msgs

namespace rosidl_generator_traits
{

[[deprecated("use ddt_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const ddt_msgs::msg::CentroidState & msg,
  std::ostream & out, size_t indentation = 0)
{
  ddt_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use ddt_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const ddt_msgs::msg::CentroidState & msg)
{
  return ddt_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<ddt_msgs::msg::CentroidState>()
{
  return "ddt_msgs::msg::CentroidState";
}

template<>
inline const char * name<ddt_msgs::msg::CentroidState>()
{
  return "ddt_msgs/msg/CentroidState";
}

template<>
struct has_fixed_size<ddt_msgs::msg::CentroidState>
  : std::integral_constant<bool, has_fixed_size<geometry_msgs::msg::Vector3>::value && has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<ddt_msgs::msg::CentroidState>
  : std::integral_constant<bool, has_bounded_size<geometry_msgs::msg::Vector3>::value && has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<ddt_msgs::msg::CentroidState>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DDT_MSGS__MSG__DETAIL__CENTROID_STATE__TRAITS_HPP_
