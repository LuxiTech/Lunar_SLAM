// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from ddt_msgs:msg/DockStatus.idl
// generated code does not contain a copyright notice
#include "ddt_msgs/msg/detail/dock_status__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"

bool
ddt_msgs__msg__DockStatus__init(ddt_msgs__msg__DockStatus * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    ddt_msgs__msg__DockStatus__fini(msg);
    return false;
  }
  // present
  // slave
  // connect
  return true;
}

void
ddt_msgs__msg__DockStatus__fini(ddt_msgs__msg__DockStatus * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // present
  // slave
  // connect
}

bool
ddt_msgs__msg__DockStatus__are_equal(const ddt_msgs__msg__DockStatus * lhs, const ddt_msgs__msg__DockStatus * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // present
  if (lhs->present != rhs->present) {
    return false;
  }
  // slave
  if (lhs->slave != rhs->slave) {
    return false;
  }
  // connect
  if (lhs->connect != rhs->connect) {
    return false;
  }
  return true;
}

bool
ddt_msgs__msg__DockStatus__copy(
  const ddt_msgs__msg__DockStatus * input,
  ddt_msgs__msg__DockStatus * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // present
  output->present = input->present;
  // slave
  output->slave = input->slave;
  // connect
  output->connect = input->connect;
  return true;
}

ddt_msgs__msg__DockStatus *
ddt_msgs__msg__DockStatus__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ddt_msgs__msg__DockStatus * msg = (ddt_msgs__msg__DockStatus *)allocator.allocate(sizeof(ddt_msgs__msg__DockStatus), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(ddt_msgs__msg__DockStatus));
  bool success = ddt_msgs__msg__DockStatus__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
ddt_msgs__msg__DockStatus__destroy(ddt_msgs__msg__DockStatus * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    ddt_msgs__msg__DockStatus__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
ddt_msgs__msg__DockStatus__Sequence__init(ddt_msgs__msg__DockStatus__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ddt_msgs__msg__DockStatus * data = NULL;

  if (size) {
    data = (ddt_msgs__msg__DockStatus *)allocator.zero_allocate(size, sizeof(ddt_msgs__msg__DockStatus), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = ddt_msgs__msg__DockStatus__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        ddt_msgs__msg__DockStatus__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
ddt_msgs__msg__DockStatus__Sequence__fini(ddt_msgs__msg__DockStatus__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      ddt_msgs__msg__DockStatus__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

ddt_msgs__msg__DockStatus__Sequence *
ddt_msgs__msg__DockStatus__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ddt_msgs__msg__DockStatus__Sequence * array = (ddt_msgs__msg__DockStatus__Sequence *)allocator.allocate(sizeof(ddt_msgs__msg__DockStatus__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = ddt_msgs__msg__DockStatus__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
ddt_msgs__msg__DockStatus__Sequence__destroy(ddt_msgs__msg__DockStatus__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    ddt_msgs__msg__DockStatus__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
ddt_msgs__msg__DockStatus__Sequence__are_equal(const ddt_msgs__msg__DockStatus__Sequence * lhs, const ddt_msgs__msg__DockStatus__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!ddt_msgs__msg__DockStatus__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
ddt_msgs__msg__DockStatus__Sequence__copy(
  const ddt_msgs__msg__DockStatus__Sequence * input,
  ddt_msgs__msg__DockStatus__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(ddt_msgs__msg__DockStatus);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    ddt_msgs__msg__DockStatus * data =
      (ddt_msgs__msg__DockStatus *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!ddt_msgs__msg__DockStatus__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          ddt_msgs__msg__DockStatus__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!ddt_msgs__msg__DockStatus__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
