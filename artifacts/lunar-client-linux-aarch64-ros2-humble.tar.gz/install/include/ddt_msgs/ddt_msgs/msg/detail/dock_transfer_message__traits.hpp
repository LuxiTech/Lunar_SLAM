// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from ddt_msgs:msg/DockTransferMessage.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__DOCK_TRANSFER_MESSAGE__TRAITS_HPP_
#define DDT_MSGS__MSG__DETAIL__DOCK_TRANSFER_MESSAGE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "ddt_msgs/msg/detail/dock_transfer_message__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace ddt_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const DockTransferMessage & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: type
  {
    out << "type: ";
    rosidl_generator_traits::value_to_yaml(msg.type, out);
    out << ", ";
  }

  // member: is_slave
  {
    out << "is_slave: ";
    rosidl_generator_traits::value_to_yaml(msg.is_slave, out);
    out << ", ";
  }

  // member: is_quadruped
  {
    out << "is_quadruped: ";
    rosidl_generator_traits::value_to_yaml(msg.is_quadruped, out);
    out << ", ";
  }

  // member: is_balance
  {
    out << "is_balance: ";
    rosidl_generator_traits::value_to_yaml(msg.is_balance, out);
    out << ", ";
  }

  // member: error
  {
    out << "error: ";
    rosidl_generator_traits::value_to_yaml(msg.error, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const DockTransferMessage & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "type: ";
    rosidl_generator_traits::value_to_yaml(msg.type, out);
    out << "\n";
  }

  // member: is_slave
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_slave: ";
    rosidl_generator_traits::value_to_yaml(msg.is_slave, out);
    out << "\n";
  }

  // member: is_quadruped
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_quadruped: ";
    rosidl_generator_traits::value_to_yaml(msg.is_quadruped, out);
    out << "\n";
  }

  // member: is_balance
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_balance: ";
    rosidl_generator_traits::value_to_yaml(msg.is_balance, out);
    out << "\n";
  }

  // member: error
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "error: ";
    rosidl_generator_traits::value_to_yaml(msg.error, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const DockTransferMessage & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace ddt_msgs

namespace rosidl_generator_traits
{

[[deprecated("use ddt_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const ddt_msgs::msg::DockTransferMessage & msg,
  std::ostream & out, size_t indentation = 0)
{
  ddt_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use ddt_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const ddt_msgs::msg::DockTransferMessage & msg)
{
  return ddt_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<ddt_msgs::msg::DockTransferMessage>()
{
  return "ddt_msgs::msg::DockTransferMessage";
}

template<>
inline const char * name<ddt_msgs::msg::DockTransferMessage>()
{
  return "ddt_msgs/msg/DockTransferMessage";
}

template<>
struct has_fixed_size<ddt_msgs::msg::DockTransferMessage>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<ddt_msgs::msg::DockTransferMessage>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<ddt_msgs::msg::DockTransferMessage>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DDT_MSGS__MSG__DETAIL__DOCK_TRANSFER_MESSAGE__TRAITS_HPP_
