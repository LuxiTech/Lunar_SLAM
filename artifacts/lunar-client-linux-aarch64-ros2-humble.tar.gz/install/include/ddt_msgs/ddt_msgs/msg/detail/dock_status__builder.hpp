// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from ddt_msgs:msg/DockStatus.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__DOCK_STATUS__BUILDER_HPP_
#define DDT_MSGS__MSG__DETAIL__DOCK_STATUS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "ddt_msgs/msg/detail/dock_status__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace ddt_msgs
{

namespace msg
{

namespace builder
{

class Init_DockStatus_connect
{
public:
  explicit Init_DockStatus_connect(::ddt_msgs::msg::DockStatus & msg)
  : msg_(msg)
  {}
  ::ddt_msgs::msg::DockStatus connect(::ddt_msgs::msg::DockStatus::_connect_type arg)
  {
    msg_.connect = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ddt_msgs::msg::DockStatus msg_;
};

class Init_DockStatus_slave
{
public:
  explicit Init_DockStatus_slave(::ddt_msgs::msg::DockStatus & msg)
  : msg_(msg)
  {}
  Init_DockStatus_connect slave(::ddt_msgs::msg::DockStatus::_slave_type arg)
  {
    msg_.slave = std::move(arg);
    return Init_DockStatus_connect(msg_);
  }

private:
  ::ddt_msgs::msg::DockStatus msg_;
};

class Init_DockStatus_present
{
public:
  explicit Init_DockStatus_present(::ddt_msgs::msg::DockStatus & msg)
  : msg_(msg)
  {}
  Init_DockStatus_slave present(::ddt_msgs::msg::DockStatus::_present_type arg)
  {
    msg_.present = std::move(arg);
    return Init_DockStatus_slave(msg_);
  }

private:
  ::ddt_msgs::msg::DockStatus msg_;
};

class Init_DockStatus_header
{
public:
  Init_DockStatus_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_DockStatus_present header(::ddt_msgs::msg::DockStatus::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_DockStatus_present(msg_);
  }

private:
  ::ddt_msgs::msg::DockStatus msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::ddt_msgs::msg::DockStatus>()
{
  return ddt_msgs::msg::builder::Init_DockStatus_header();
}

}  // namespace ddt_msgs

#endif  // DDT_MSGS__MSG__DETAIL__DOCK_STATUS__BUILDER_HPP_
