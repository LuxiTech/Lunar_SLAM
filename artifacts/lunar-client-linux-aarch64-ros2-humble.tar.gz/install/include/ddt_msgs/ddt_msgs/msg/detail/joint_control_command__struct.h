// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from ddt_msgs:msg/JointControlCommand.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__JOINT_CONTROL_COMMAND__STRUCT_H_
#define DDT_MSGS__MSG__DETAIL__JOINT_CONTROL_COMMAND__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'name'
#include "rosidl_runtime_c/string.h"
// Member 'kp'
// Member 'kd'
// Member 'position'
// Member 'velocity'
// Member 'effort'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/JointControlCommand in the package ddt_msgs.
typedef struct ddt_msgs__msg__JointControlCommand
{
  std_msgs__msg__Header header;
  rosidl_runtime_c__String__Sequence name;
  rosidl_runtime_c__double__Sequence kp;
  rosidl_runtime_c__double__Sequence kd;
  rosidl_runtime_c__double__Sequence position;
  rosidl_runtime_c__double__Sequence velocity;
  rosidl_runtime_c__double__Sequence effort;
} ddt_msgs__msg__JointControlCommand;

// Struct for a sequence of ddt_msgs__msg__JointControlCommand.
typedef struct ddt_msgs__msg__JointControlCommand__Sequence
{
  ddt_msgs__msg__JointControlCommand * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} ddt_msgs__msg__JointControlCommand__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DDT_MSGS__MSG__DETAIL__JOINT_CONTROL_COMMAND__STRUCT_H_
