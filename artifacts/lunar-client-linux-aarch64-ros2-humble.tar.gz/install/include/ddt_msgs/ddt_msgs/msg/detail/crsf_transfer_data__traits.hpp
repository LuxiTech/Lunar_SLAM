// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from ddt_msgs:msg/CrsfTransferData.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__CRSF_TRANSFER_DATA__TRAITS_HPP_
#define DDT_MSGS__MSG__DETAIL__CRSF_TRANSFER_DATA__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "ddt_msgs/msg/detail/crsf_transfer_data__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace ddt_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const CrsfTransferData & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: version
  {
    out << "version: ";
    rosidl_generator_traits::value_to_yaml(msg.version, out);
    out << ", ";
  }

  // member: error_code
  {
    out << "error_code: ";
    rosidl_generator_traits::value_to_yaml(msg.error_code, out);
    out << ", ";
  }

  // member: buttons
  {
    if (msg.buttons.size() == 0) {
      out << "buttons: []";
    } else {
      out << "buttons: [";
      size_t pending_items = msg.buttons.size();
      for (auto item : msg.buttons) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: bat
  {
    if (msg.bat.size() == 0) {
      out << "bat: []";
    } else {
      out << "bat: [";
      size_t pending_items = msg.bat.size();
      for (auto item : msg.bat) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const CrsfTransferData & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: version
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "version: ";
    rosidl_generator_traits::value_to_yaml(msg.version, out);
    out << "\n";
  }

  // member: error_code
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "error_code: ";
    rosidl_generator_traits::value_to_yaml(msg.error_code, out);
    out << "\n";
  }

  // member: buttons
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.buttons.size() == 0) {
      out << "buttons: []\n";
    } else {
      out << "buttons:\n";
      for (auto item : msg.buttons) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: bat
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.bat.size() == 0) {
      out << "bat: []\n";
    } else {
      out << "bat:\n";
      for (auto item : msg.bat) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const CrsfTransferData & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace ddt_msgs

namespace rosidl_generator_traits
{

[[deprecated("use ddt_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const ddt_msgs::msg::CrsfTransferData & msg,
  std::ostream & out, size_t indentation = 0)
{
  ddt_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use ddt_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const ddt_msgs::msg::CrsfTransferData & msg)
{
  return ddt_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<ddt_msgs::msg::CrsfTransferData>()
{
  return "ddt_msgs::msg::CrsfTransferData";
}

template<>
inline const char * name<ddt_msgs::msg::CrsfTransferData>()
{
  return "ddt_msgs/msg/CrsfTransferData";
}

template<>
struct has_fixed_size<ddt_msgs::msg::CrsfTransferData>
  : std::integral_constant<bool, has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<ddt_msgs::msg::CrsfTransferData>
  : std::integral_constant<bool, has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<ddt_msgs::msg::CrsfTransferData>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DDT_MSGS__MSG__DETAIL__CRSF_TRANSFER_DATA__TRAITS_HPP_
