// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from ddt_msgs:msg/CrsfTransferData.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__CRSF_TRANSFER_DATA__STRUCT_HPP_
#define DDT_MSGS__MSG__DETAIL__CRSF_TRANSFER_DATA__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__ddt_msgs__msg__CrsfTransferData __attribute__((deprecated))
#else
# define DEPRECATED__ddt_msgs__msg__CrsfTransferData __declspec(deprecated)
#endif

namespace ddt_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct CrsfTransferData_
{
  using Type = CrsfTransferData_<ContainerAllocator>;

  explicit CrsfTransferData_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->version = 0ul;
      this->error_code = 0ul;
      std::fill<typename std::array<uint8_t, 16>::iterator, uint8_t>(this->buttons.begin(), this->buttons.end(), 0);
      std::fill<typename std::array<uint8_t, 2>::iterator, uint8_t>(this->bat.begin(), this->bat.end(), 0);
    }
  }

  explicit CrsfTransferData_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    buttons(_alloc),
    bat(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->version = 0ul;
      this->error_code = 0ul;
      std::fill<typename std::array<uint8_t, 16>::iterator, uint8_t>(this->buttons.begin(), this->buttons.end(), 0);
      std::fill<typename std::array<uint8_t, 2>::iterator, uint8_t>(this->bat.begin(), this->bat.end(), 0);
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _version_type =
    uint32_t;
  _version_type version;
  using _error_code_type =
    uint32_t;
  _error_code_type error_code;
  using _buttons_type =
    std::array<uint8_t, 16>;
  _buttons_type buttons;
  using _bat_type =
    std::array<uint8_t, 2>;
  _bat_type bat;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__version(
    const uint32_t & _arg)
  {
    this->version = _arg;
    return *this;
  }
  Type & set__error_code(
    const uint32_t & _arg)
  {
    this->error_code = _arg;
    return *this;
  }
  Type & set__buttons(
    const std::array<uint8_t, 16> & _arg)
  {
    this->buttons = _arg;
    return *this;
  }
  Type & set__bat(
    const std::array<uint8_t, 2> & _arg)
  {
    this->bat = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    ddt_msgs::msg::CrsfTransferData_<ContainerAllocator> *;
  using ConstRawPtr =
    const ddt_msgs::msg::CrsfTransferData_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<ddt_msgs::msg::CrsfTransferData_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<ddt_msgs::msg::CrsfTransferData_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      ddt_msgs::msg::CrsfTransferData_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<ddt_msgs::msg::CrsfTransferData_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      ddt_msgs::msg::CrsfTransferData_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<ddt_msgs::msg::CrsfTransferData_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<ddt_msgs::msg::CrsfTransferData_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<ddt_msgs::msg::CrsfTransferData_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__ddt_msgs__msg__CrsfTransferData
    std::shared_ptr<ddt_msgs::msg::CrsfTransferData_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__ddt_msgs__msg__CrsfTransferData
    std::shared_ptr<ddt_msgs::msg::CrsfTransferData_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const CrsfTransferData_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->version != other.version) {
      return false;
    }
    if (this->error_code != other.error_code) {
      return false;
    }
    if (this->buttons != other.buttons) {
      return false;
    }
    if (this->bat != other.bat) {
      return false;
    }
    return true;
  }
  bool operator!=(const CrsfTransferData_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct CrsfTransferData_

// alias to use template instance with default allocator
using CrsfTransferData =
  ddt_msgs::msg::CrsfTransferData_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace ddt_msgs

#endif  // DDT_MSGS__MSG__DETAIL__CRSF_TRANSFER_DATA__STRUCT_HPP_
