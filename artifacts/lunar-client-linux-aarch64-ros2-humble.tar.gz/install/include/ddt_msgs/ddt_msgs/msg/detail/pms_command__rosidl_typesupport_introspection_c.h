// generated from rosidl_typesupport_introspection_c/resource/idl__rosidl_typesupport_introspection_c.h.em
// with input from ddt_msgs:msg/PMSCommand.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__PMS_COMMAND__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_
#define DDT_MSGS__MSG__DETAIL__PMS_COMMAND__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_

#ifdef __cplusplus
extern "C"
{
#endif


#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "ddt_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"

ROSIDL_TYPESUPPORT_INTROSPECTION_C_PUBLIC_ddt_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, ddt_msgs, msg, PMSCommand)();

#ifdef __cplusplus
}
#endif

#endif  // DDT_MSGS__MSG__DETAIL__PMS_COMMAND__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_
