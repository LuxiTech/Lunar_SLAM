// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from ddt_msgs:msg/CrsfTransferData.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "ddt_msgs/msg/detail/crsf_transfer_data__rosidl_typesupport_introspection_c.h"
#include "ddt_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "ddt_msgs/msg/detail/crsf_transfer_data__functions.h"
#include "ddt_msgs/msg/detail/crsf_transfer_data__struct.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/header.h"
// Member `header`
#include "std_msgs/msg/detail/header__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__CrsfTransferData_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  ddt_msgs__msg__CrsfTransferData__init(message_memory);
}

void ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__CrsfTransferData_fini_function(void * message_memory)
{
  ddt_msgs__msg__CrsfTransferData__fini(message_memory);
}

size_t ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__size_function__CrsfTransferData__buttons(
  const void * untyped_member)
{
  (void)untyped_member;
  return 16;
}

const void * ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__get_const_function__CrsfTransferData__buttons(
  const void * untyped_member, size_t index)
{
  const uint8_t * member =
    (const uint8_t *)(untyped_member);
  return &member[index];
}

void * ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__get_function__CrsfTransferData__buttons(
  void * untyped_member, size_t index)
{
  uint8_t * member =
    (uint8_t *)(untyped_member);
  return &member[index];
}

void ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__fetch_function__CrsfTransferData__buttons(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__get_const_function__CrsfTransferData__buttons(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__assign_function__CrsfTransferData__buttons(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__get_function__CrsfTransferData__buttons(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

size_t ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__size_function__CrsfTransferData__bat(
  const void * untyped_member)
{
  (void)untyped_member;
  return 2;
}

const void * ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__get_const_function__CrsfTransferData__bat(
  const void * untyped_member, size_t index)
{
  const uint8_t * member =
    (const uint8_t *)(untyped_member);
  return &member[index];
}

void * ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__get_function__CrsfTransferData__bat(
  void * untyped_member, size_t index)
{
  uint8_t * member =
    (uint8_t *)(untyped_member);
  return &member[index];
}

void ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__fetch_function__CrsfTransferData__bat(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const uint8_t * item =
    ((const uint8_t *)
    ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__get_const_function__CrsfTransferData__bat(untyped_member, index));
  uint8_t * value =
    (uint8_t *)(untyped_value);
  *value = *item;
}

void ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__assign_function__CrsfTransferData__bat(
  void * untyped_member, size_t index, const void * untyped_value)
{
  uint8_t * item =
    ((uint8_t *)
    ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__get_function__CrsfTransferData__bat(untyped_member, index));
  const uint8_t * value =
    (const uint8_t *)(untyped_value);
  *item = *value;
}

static rosidl_typesupport_introspection_c__MessageMember ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__CrsfTransferData_message_member_array[5] = {
  {
    "header",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(ddt_msgs__msg__CrsfTransferData, header),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "version",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(ddt_msgs__msg__CrsfTransferData, version),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "error_code",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT32,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(ddt_msgs__msg__CrsfTransferData, error_code),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "buttons",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    16,  // array size
    false,  // is upper bound
    offsetof(ddt_msgs__msg__CrsfTransferData, buttons),  // bytes offset in struct
    NULL,  // default value
    ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__size_function__CrsfTransferData__buttons,  // size() function pointer
    ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__get_const_function__CrsfTransferData__buttons,  // get_const(index) function pointer
    ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__get_function__CrsfTransferData__buttons,  // get(index) function pointer
    ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__fetch_function__CrsfTransferData__buttons,  // fetch(index, &value) function pointer
    ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__assign_function__CrsfTransferData__buttons,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "bat",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_UINT8,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    true,  // is array
    2,  // array size
    false,  // is upper bound
    offsetof(ddt_msgs__msg__CrsfTransferData, bat),  // bytes offset in struct
    NULL,  // default value
    ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__size_function__CrsfTransferData__bat,  // size() function pointer
    ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__get_const_function__CrsfTransferData__bat,  // get_const(index) function pointer
    ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__get_function__CrsfTransferData__bat,  // get(index) function pointer
    ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__fetch_function__CrsfTransferData__bat,  // fetch(index, &value) function pointer
    ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__assign_function__CrsfTransferData__bat,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__CrsfTransferData_message_members = {
  "ddt_msgs__msg",  // message namespace
  "CrsfTransferData",  // message name
  5,  // number of fields
  sizeof(ddt_msgs__msg__CrsfTransferData),
  ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__CrsfTransferData_message_member_array,  // message members
  ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__CrsfTransferData_init_function,  // function to initialize message memory (memory has to be allocated)
  ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__CrsfTransferData_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__CrsfTransferData_message_type_support_handle = {
  0,
  &ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__CrsfTransferData_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_ddt_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, ddt_msgs, msg, CrsfTransferData)() {
  ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__CrsfTransferData_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, std_msgs, msg, Header)();
  if (!ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__CrsfTransferData_message_type_support_handle.typesupport_identifier) {
    ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__CrsfTransferData_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &ddt_msgs__msg__CrsfTransferData__rosidl_typesupport_introspection_c__CrsfTransferData_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
