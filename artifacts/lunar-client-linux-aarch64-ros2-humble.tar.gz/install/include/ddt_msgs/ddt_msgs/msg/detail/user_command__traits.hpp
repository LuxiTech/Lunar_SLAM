// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from ddt_msgs:msg/UserCommand.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__USER_COMMAND__TRAITS_HPP_
#define DDT_MSGS__MSG__DETAIL__USER_COMMAND__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "ddt_msgs/msg/detail/user_command__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'pose'
#include "geometry_msgs/msg/detail/pose__traits.hpp"
// Member 'twist'
#include "geometry_msgs/msg/detail/twist__traits.hpp"

namespace ddt_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const UserCommand & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: fsm_mode
  {
    out << "fsm_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.fsm_mode, out);
    out << ", ";
  }

  // member: pose
  {
    out << "pose: ";
    to_flow_style_yaml(msg.pose, out);
    out << ", ";
  }

  // member: twist
  {
    out << "twist: ";
    to_flow_style_yaml(msg.twist, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const UserCommand & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: fsm_mode
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "fsm_mode: ";
    rosidl_generator_traits::value_to_yaml(msg.fsm_mode, out);
    out << "\n";
  }

  // member: pose
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pose:\n";
    to_block_style_yaml(msg.pose, out, indentation + 2);
  }

  // member: twist
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "twist:\n";
    to_block_style_yaml(msg.twist, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const UserCommand & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace ddt_msgs

namespace rosidl_generator_traits
{

[[deprecated("use ddt_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const ddt_msgs::msg::UserCommand & msg,
  std::ostream & out, size_t indentation = 0)
{
  ddt_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use ddt_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const ddt_msgs::msg::UserCommand & msg)
{
  return ddt_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<ddt_msgs::msg::UserCommand>()
{
  return "ddt_msgs::msg::UserCommand";
}

template<>
inline const char * name<ddt_msgs::msg::UserCommand>()
{
  return "ddt_msgs/msg/UserCommand";
}

template<>
struct has_fixed_size<ddt_msgs::msg::UserCommand>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<ddt_msgs::msg::UserCommand>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<ddt_msgs::msg::UserCommand>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // DDT_MSGS__MSG__DETAIL__USER_COMMAND__TRAITS_HPP_
