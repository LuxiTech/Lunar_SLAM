// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from ddt_msgs:msg/CrsfTransferData.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__CRSF_TRANSFER_DATA__BUILDER_HPP_
#define DDT_MSGS__MSG__DETAIL__CRSF_TRANSFER_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "ddt_msgs/msg/detail/crsf_transfer_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace ddt_msgs
{

namespace msg
{

namespace builder
{

class Init_CrsfTransferData_bat
{
public:
  explicit Init_CrsfTransferData_bat(::ddt_msgs::msg::CrsfTransferData & msg)
  : msg_(msg)
  {}
  ::ddt_msgs::msg::CrsfTransferData bat(::ddt_msgs::msg::CrsfTransferData::_bat_type arg)
  {
    msg_.bat = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ddt_msgs::msg::CrsfTransferData msg_;
};

class Init_CrsfTransferData_buttons
{
public:
  explicit Init_CrsfTransferData_buttons(::ddt_msgs::msg::CrsfTransferData & msg)
  : msg_(msg)
  {}
  Init_CrsfTransferData_bat buttons(::ddt_msgs::msg::CrsfTransferData::_buttons_type arg)
  {
    msg_.buttons = std::move(arg);
    return Init_CrsfTransferData_bat(msg_);
  }

private:
  ::ddt_msgs::msg::CrsfTransferData msg_;
};

class Init_CrsfTransferData_error_code
{
public:
  explicit Init_CrsfTransferData_error_code(::ddt_msgs::msg::CrsfTransferData & msg)
  : msg_(msg)
  {}
  Init_CrsfTransferData_buttons error_code(::ddt_msgs::msg::CrsfTransferData::_error_code_type arg)
  {
    msg_.error_code = std::move(arg);
    return Init_CrsfTransferData_buttons(msg_);
  }

private:
  ::ddt_msgs::msg::CrsfTransferData msg_;
};

class Init_CrsfTransferData_version
{
public:
  explicit Init_CrsfTransferData_version(::ddt_msgs::msg::CrsfTransferData & msg)
  : msg_(msg)
  {}
  Init_CrsfTransferData_error_code version(::ddt_msgs::msg::CrsfTransferData::_version_type arg)
  {
    msg_.version = std::move(arg);
    return Init_CrsfTransferData_error_code(msg_);
  }

private:
  ::ddt_msgs::msg::CrsfTransferData msg_;
};

class Init_CrsfTransferData_header
{
public:
  Init_CrsfTransferData_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CrsfTransferData_version header(::ddt_msgs::msg::CrsfTransferData::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_CrsfTransferData_version(msg_);
  }

private:
  ::ddt_msgs::msg::CrsfTransferData msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::ddt_msgs::msg::CrsfTransferData>()
{
  return ddt_msgs::msg::builder::Init_CrsfTransferData_header();
}

}  // namespace ddt_msgs

#endif  // DDT_MSGS__MSG__DETAIL__CRSF_TRANSFER_DATA__BUILDER_HPP_
