// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from ddt_msgs:msg/PMSCommand.idl
// generated code does not contain a copyright notice
#include "ddt_msgs/msg/detail/pms_command__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `data`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
ddt_msgs__msg__PMSCommand__init(ddt_msgs__msg__PMSCommand * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    ddt_msgs__msg__PMSCommand__fini(msg);
    return false;
  }
  // cmd
  // data
  if (!rosidl_runtime_c__uint8__Sequence__init(&msg->data, 0)) {
    ddt_msgs__msg__PMSCommand__fini(msg);
    return false;
  }
  return true;
}

void
ddt_msgs__msg__PMSCommand__fini(ddt_msgs__msg__PMSCommand * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // cmd
  // data
  rosidl_runtime_c__uint8__Sequence__fini(&msg->data);
}

bool
ddt_msgs__msg__PMSCommand__are_equal(const ddt_msgs__msg__PMSCommand * lhs, const ddt_msgs__msg__PMSCommand * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // cmd
  if (lhs->cmd != rhs->cmd) {
    return false;
  }
  // data
  if (!rosidl_runtime_c__uint8__Sequence__are_equal(
      &(lhs->data), &(rhs->data)))
  {
    return false;
  }
  return true;
}

bool
ddt_msgs__msg__PMSCommand__copy(
  const ddt_msgs__msg__PMSCommand * input,
  ddt_msgs__msg__PMSCommand * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // cmd
  output->cmd = input->cmd;
  // data
  if (!rosidl_runtime_c__uint8__Sequence__copy(
      &(input->data), &(output->data)))
  {
    return false;
  }
  return true;
}

ddt_msgs__msg__PMSCommand *
ddt_msgs__msg__PMSCommand__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ddt_msgs__msg__PMSCommand * msg = (ddt_msgs__msg__PMSCommand *)allocator.allocate(sizeof(ddt_msgs__msg__PMSCommand), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(ddt_msgs__msg__PMSCommand));
  bool success = ddt_msgs__msg__PMSCommand__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
ddt_msgs__msg__PMSCommand__destroy(ddt_msgs__msg__PMSCommand * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    ddt_msgs__msg__PMSCommand__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
ddt_msgs__msg__PMSCommand__Sequence__init(ddt_msgs__msg__PMSCommand__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ddt_msgs__msg__PMSCommand * data = NULL;

  if (size) {
    data = (ddt_msgs__msg__PMSCommand *)allocator.zero_allocate(size, sizeof(ddt_msgs__msg__PMSCommand), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = ddt_msgs__msg__PMSCommand__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        ddt_msgs__msg__PMSCommand__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
ddt_msgs__msg__PMSCommand__Sequence__fini(ddt_msgs__msg__PMSCommand__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      ddt_msgs__msg__PMSCommand__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

ddt_msgs__msg__PMSCommand__Sequence *
ddt_msgs__msg__PMSCommand__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ddt_msgs__msg__PMSCommand__Sequence * array = (ddt_msgs__msg__PMSCommand__Sequence *)allocator.allocate(sizeof(ddt_msgs__msg__PMSCommand__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = ddt_msgs__msg__PMSCommand__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
ddt_msgs__msg__PMSCommand__Sequence__destroy(ddt_msgs__msg__PMSCommand__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    ddt_msgs__msg__PMSCommand__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
ddt_msgs__msg__PMSCommand__Sequence__are_equal(const ddt_msgs__msg__PMSCommand__Sequence * lhs, const ddt_msgs__msg__PMSCommand__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!ddt_msgs__msg__PMSCommand__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
ddt_msgs__msg__PMSCommand__Sequence__copy(
  const ddt_msgs__msg__PMSCommand__Sequence * input,
  ddt_msgs__msg__PMSCommand__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(ddt_msgs__msg__PMSCommand);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    ddt_msgs__msg__PMSCommand * data =
      (ddt_msgs__msg__PMSCommand *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!ddt_msgs__msg__PMSCommand__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          ddt_msgs__msg__PMSCommand__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!ddt_msgs__msg__PMSCommand__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
