// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from ddt_msgs:msg/DockTransferMessage.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__DOCK_TRANSFER_MESSAGE__TYPE_SUPPORT_HPP_
#define DDT_MSGS__MSG__DETAIL__DOCK_TRANSFER_MESSAGE__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "ddt_msgs/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_ddt_msgs
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  ddt_msgs,
  msg,
  DockTransferMessage
)();
#ifdef __cplusplus
}
#endif

#endif  // DDT_MSGS__MSG__DETAIL__DOCK_TRANSFER_MESSAGE__TYPE_SUPPORT_HPP_
