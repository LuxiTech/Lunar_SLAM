// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from ddt_msgs:msg/JointControlCommand.idl
// generated code does not contain a copyright notice
#include "ddt_msgs/msg/detail/joint_control_command__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `name`
#include "rosidl_runtime_c/string_functions.h"
// Member `kp`
// Member `kd`
// Member `position`
// Member `velocity`
// Member `effort`
#include "rosidl_runtime_c/primitives_sequence_functions.h"

bool
ddt_msgs__msg__JointControlCommand__init(ddt_msgs__msg__JointControlCommand * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    ddt_msgs__msg__JointControlCommand__fini(msg);
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__Sequence__init(&msg->name, 0)) {
    ddt_msgs__msg__JointControlCommand__fini(msg);
    return false;
  }
  // kp
  if (!rosidl_runtime_c__double__Sequence__init(&msg->kp, 0)) {
    ddt_msgs__msg__JointControlCommand__fini(msg);
    return false;
  }
  // kd
  if (!rosidl_runtime_c__double__Sequence__init(&msg->kd, 0)) {
    ddt_msgs__msg__JointControlCommand__fini(msg);
    return false;
  }
  // position
  if (!rosidl_runtime_c__double__Sequence__init(&msg->position, 0)) {
    ddt_msgs__msg__JointControlCommand__fini(msg);
    return false;
  }
  // velocity
  if (!rosidl_runtime_c__double__Sequence__init(&msg->velocity, 0)) {
    ddt_msgs__msg__JointControlCommand__fini(msg);
    return false;
  }
  // effort
  if (!rosidl_runtime_c__double__Sequence__init(&msg->effort, 0)) {
    ddt_msgs__msg__JointControlCommand__fini(msg);
    return false;
  }
  return true;
}

void
ddt_msgs__msg__JointControlCommand__fini(ddt_msgs__msg__JointControlCommand * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // name
  rosidl_runtime_c__String__Sequence__fini(&msg->name);
  // kp
  rosidl_runtime_c__double__Sequence__fini(&msg->kp);
  // kd
  rosidl_runtime_c__double__Sequence__fini(&msg->kd);
  // position
  rosidl_runtime_c__double__Sequence__fini(&msg->position);
  // velocity
  rosidl_runtime_c__double__Sequence__fini(&msg->velocity);
  // effort
  rosidl_runtime_c__double__Sequence__fini(&msg->effort);
}

bool
ddt_msgs__msg__JointControlCommand__are_equal(const ddt_msgs__msg__JointControlCommand * lhs, const ddt_msgs__msg__JointControlCommand * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__Sequence__are_equal(
      &(lhs->name), &(rhs->name)))
  {
    return false;
  }
  // kp
  if (!rosidl_runtime_c__double__Sequence__are_equal(
      &(lhs->kp), &(rhs->kp)))
  {
    return false;
  }
  // kd
  if (!rosidl_runtime_c__double__Sequence__are_equal(
      &(lhs->kd), &(rhs->kd)))
  {
    return false;
  }
  // position
  if (!rosidl_runtime_c__double__Sequence__are_equal(
      &(lhs->position), &(rhs->position)))
  {
    return false;
  }
  // velocity
  if (!rosidl_runtime_c__double__Sequence__are_equal(
      &(lhs->velocity), &(rhs->velocity)))
  {
    return false;
  }
  // effort
  if (!rosidl_runtime_c__double__Sequence__are_equal(
      &(lhs->effort), &(rhs->effort)))
  {
    return false;
  }
  return true;
}

bool
ddt_msgs__msg__JointControlCommand__copy(
  const ddt_msgs__msg__JointControlCommand * input,
  ddt_msgs__msg__JointControlCommand * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__Sequence__copy(
      &(input->name), &(output->name)))
  {
    return false;
  }
  // kp
  if (!rosidl_runtime_c__double__Sequence__copy(
      &(input->kp), &(output->kp)))
  {
    return false;
  }
  // kd
  if (!rosidl_runtime_c__double__Sequence__copy(
      &(input->kd), &(output->kd)))
  {
    return false;
  }
  // position
  if (!rosidl_runtime_c__double__Sequence__copy(
      &(input->position), &(output->position)))
  {
    return false;
  }
  // velocity
  if (!rosidl_runtime_c__double__Sequence__copy(
      &(input->velocity), &(output->velocity)))
  {
    return false;
  }
  // effort
  if (!rosidl_runtime_c__double__Sequence__copy(
      &(input->effort), &(output->effort)))
  {
    return false;
  }
  return true;
}

ddt_msgs__msg__JointControlCommand *
ddt_msgs__msg__JointControlCommand__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ddt_msgs__msg__JointControlCommand * msg = (ddt_msgs__msg__JointControlCommand *)allocator.allocate(sizeof(ddt_msgs__msg__JointControlCommand), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(ddt_msgs__msg__JointControlCommand));
  bool success = ddt_msgs__msg__JointControlCommand__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
ddt_msgs__msg__JointControlCommand__destroy(ddt_msgs__msg__JointControlCommand * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    ddt_msgs__msg__JointControlCommand__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
ddt_msgs__msg__JointControlCommand__Sequence__init(ddt_msgs__msg__JointControlCommand__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ddt_msgs__msg__JointControlCommand * data = NULL;

  if (size) {
    data = (ddt_msgs__msg__JointControlCommand *)allocator.zero_allocate(size, sizeof(ddt_msgs__msg__JointControlCommand), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = ddt_msgs__msg__JointControlCommand__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        ddt_msgs__msg__JointControlCommand__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
ddt_msgs__msg__JointControlCommand__Sequence__fini(ddt_msgs__msg__JointControlCommand__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      ddt_msgs__msg__JointControlCommand__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

ddt_msgs__msg__JointControlCommand__Sequence *
ddt_msgs__msg__JointControlCommand__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  ddt_msgs__msg__JointControlCommand__Sequence * array = (ddt_msgs__msg__JointControlCommand__Sequence *)allocator.allocate(sizeof(ddt_msgs__msg__JointControlCommand__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = ddt_msgs__msg__JointControlCommand__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
ddt_msgs__msg__JointControlCommand__Sequence__destroy(ddt_msgs__msg__JointControlCommand__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    ddt_msgs__msg__JointControlCommand__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
ddt_msgs__msg__JointControlCommand__Sequence__are_equal(const ddt_msgs__msg__JointControlCommand__Sequence * lhs, const ddt_msgs__msg__JointControlCommand__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!ddt_msgs__msg__JointControlCommand__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
ddt_msgs__msg__JointControlCommand__Sequence__copy(
  const ddt_msgs__msg__JointControlCommand__Sequence * input,
  ddt_msgs__msg__JointControlCommand__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(ddt_msgs__msg__JointControlCommand);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    ddt_msgs__msg__JointControlCommand * data =
      (ddt_msgs__msg__JointControlCommand *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!ddt_msgs__msg__JointControlCommand__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          ddt_msgs__msg__JointControlCommand__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!ddt_msgs__msg__JointControlCommand__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
