// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from ddt_msgs:msg/JointControlCommand.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__JOINT_CONTROL_COMMAND__BUILDER_HPP_
#define DDT_MSGS__MSG__DETAIL__JOINT_CONTROL_COMMAND__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "ddt_msgs/msg/detail/joint_control_command__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace ddt_msgs
{

namespace msg
{

namespace builder
{

class Init_JointControlCommand_effort
{
public:
  explicit Init_JointControlCommand_effort(::ddt_msgs::msg::JointControlCommand & msg)
  : msg_(msg)
  {}
  ::ddt_msgs::msg::JointControlCommand effort(::ddt_msgs::msg::JointControlCommand::_effort_type arg)
  {
    msg_.effort = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ddt_msgs::msg::JointControlCommand msg_;
};

class Init_JointControlCommand_velocity
{
public:
  explicit Init_JointControlCommand_velocity(::ddt_msgs::msg::JointControlCommand & msg)
  : msg_(msg)
  {}
  Init_JointControlCommand_effort velocity(::ddt_msgs::msg::JointControlCommand::_velocity_type arg)
  {
    msg_.velocity = std::move(arg);
    return Init_JointControlCommand_effort(msg_);
  }

private:
  ::ddt_msgs::msg::JointControlCommand msg_;
};

class Init_JointControlCommand_position
{
public:
  explicit Init_JointControlCommand_position(::ddt_msgs::msg::JointControlCommand & msg)
  : msg_(msg)
  {}
  Init_JointControlCommand_velocity position(::ddt_msgs::msg::JointControlCommand::_position_type arg)
  {
    msg_.position = std::move(arg);
    return Init_JointControlCommand_velocity(msg_);
  }

private:
  ::ddt_msgs::msg::JointControlCommand msg_;
};

class Init_JointControlCommand_kd
{
public:
  explicit Init_JointControlCommand_kd(::ddt_msgs::msg::JointControlCommand & msg)
  : msg_(msg)
  {}
  Init_JointControlCommand_position kd(::ddt_msgs::msg::JointControlCommand::_kd_type arg)
  {
    msg_.kd = std::move(arg);
    return Init_JointControlCommand_position(msg_);
  }

private:
  ::ddt_msgs::msg::JointControlCommand msg_;
};

class Init_JointControlCommand_kp
{
public:
  explicit Init_JointControlCommand_kp(::ddt_msgs::msg::JointControlCommand & msg)
  : msg_(msg)
  {}
  Init_JointControlCommand_kd kp(::ddt_msgs::msg::JointControlCommand::_kp_type arg)
  {
    msg_.kp = std::move(arg);
    return Init_JointControlCommand_kd(msg_);
  }

private:
  ::ddt_msgs::msg::JointControlCommand msg_;
};

class Init_JointControlCommand_name
{
public:
  explicit Init_JointControlCommand_name(::ddt_msgs::msg::JointControlCommand & msg)
  : msg_(msg)
  {}
  Init_JointControlCommand_kp name(::ddt_msgs::msg::JointControlCommand::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_JointControlCommand_kp(msg_);
  }

private:
  ::ddt_msgs::msg::JointControlCommand msg_;
};

class Init_JointControlCommand_header
{
public:
  Init_JointControlCommand_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_JointControlCommand_name header(::ddt_msgs::msg::JointControlCommand::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_JointControlCommand_name(msg_);
  }

private:
  ::ddt_msgs::msg::JointControlCommand msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::ddt_msgs::msg::JointControlCommand>()
{
  return ddt_msgs::msg::builder::Init_JointControlCommand_header();
}

}  // namespace ddt_msgs

#endif  // DDT_MSGS__MSG__DETAIL__JOINT_CONTROL_COMMAND__BUILDER_HPP_
