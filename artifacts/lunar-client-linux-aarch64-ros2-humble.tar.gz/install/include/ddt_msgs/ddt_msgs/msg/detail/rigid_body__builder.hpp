// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from ddt_msgs:msg/RigidBody.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__RIGID_BODY__BUILDER_HPP_
#define DDT_MSGS__MSG__DETAIL__RIGID_BODY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "ddt_msgs/msg/detail/rigid_body__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace ddt_msgs
{

namespace msg
{

namespace builder
{

class Init_RigidBody_transform
{
public:
  explicit Init_RigidBody_transform(::ddt_msgs::msg::RigidBody & msg)
  : msg_(msg)
  {}
  ::ddt_msgs::msg::RigidBody transform(::ddt_msgs::msg::RigidBody::_transform_type arg)
  {
    msg_.transform = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ddt_msgs::msg::RigidBody msg_;
};

class Init_RigidBody_inertia
{
public:
  Init_RigidBody_inertia()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RigidBody_transform inertia(::ddt_msgs::msg::RigidBody::_inertia_type arg)
  {
    msg_.inertia = std::move(arg);
    return Init_RigidBody_transform(msg_);
  }

private:
  ::ddt_msgs::msg::RigidBody msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::ddt_msgs::msg::RigidBody>()
{
  return ddt_msgs::msg::builder::Init_RigidBody_inertia();
}

}  // namespace ddt_msgs

#endif  // DDT_MSGS__MSG__DETAIL__RIGID_BODY__BUILDER_HPP_
