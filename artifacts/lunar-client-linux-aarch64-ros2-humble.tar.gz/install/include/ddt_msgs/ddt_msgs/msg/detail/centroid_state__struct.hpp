// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from ddt_msgs:msg/CentroidState.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__CENTROID_STATE__STRUCT_HPP_
#define DDT_MSGS__MSG__DETAIL__CENTROID_STATE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"
// Member 'whole_body_com'
#include "geometry_msgs/msg/detail/vector3__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__ddt_msgs__msg__CentroidState __attribute__((deprecated))
#else
# define DEPRECATED__ddt_msgs__msg__CentroidState __declspec(deprecated)
#endif

namespace ddt_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct CentroidState_
{
  using Type = CentroidState_<ContainerAllocator>;

  explicit CentroidState_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init),
    whole_body_com(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->set_tilt = 0.0;
    }
  }

  explicit CentroidState_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init),
    whole_body_com(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->set_tilt = 0.0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _whole_body_com_type =
    geometry_msgs::msg::Vector3_<ContainerAllocator>;
  _whole_body_com_type whole_body_com;
  using _set_tilt_type =
    double;
  _set_tilt_type set_tilt;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__whole_body_com(
    const geometry_msgs::msg::Vector3_<ContainerAllocator> & _arg)
  {
    this->whole_body_com = _arg;
    return *this;
  }
  Type & set__set_tilt(
    const double & _arg)
  {
    this->set_tilt = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    ddt_msgs::msg::CentroidState_<ContainerAllocator> *;
  using ConstRawPtr =
    const ddt_msgs::msg::CentroidState_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<ddt_msgs::msg::CentroidState_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<ddt_msgs::msg::CentroidState_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      ddt_msgs::msg::CentroidState_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<ddt_msgs::msg::CentroidState_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      ddt_msgs::msg::CentroidState_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<ddt_msgs::msg::CentroidState_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<ddt_msgs::msg::CentroidState_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<ddt_msgs::msg::CentroidState_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__ddt_msgs__msg__CentroidState
    std::shared_ptr<ddt_msgs::msg::CentroidState_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__ddt_msgs__msg__CentroidState
    std::shared_ptr<ddt_msgs::msg::CentroidState_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const CentroidState_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->whole_body_com != other.whole_body_com) {
      return false;
    }
    if (this->set_tilt != other.set_tilt) {
      return false;
    }
    return true;
  }
  bool operator!=(const CentroidState_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct CentroidState_

// alias to use template instance with default allocator
using CentroidState =
  ddt_msgs::msg::CentroidState_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace ddt_msgs

#endif  // DDT_MSGS__MSG__DETAIL__CENTROID_STATE__STRUCT_HPP_
