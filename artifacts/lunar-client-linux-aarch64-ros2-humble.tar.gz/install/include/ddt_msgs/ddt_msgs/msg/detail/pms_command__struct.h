// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from ddt_msgs:msg/PMSCommand.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__PMS_COMMAND__STRUCT_H_
#define DDT_MSGS__MSG__DETAIL__PMS_COMMAND__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'data'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/PMSCommand in the package ddt_msgs.
typedef struct ddt_msgs__msg__PMSCommand
{
  std_msgs__msg__Header header;
  uint32_t cmd;
  rosidl_runtime_c__uint8__Sequence data;
} ddt_msgs__msg__PMSCommand;

// Struct for a sequence of ddt_msgs__msg__PMSCommand.
typedef struct ddt_msgs__msg__PMSCommand__Sequence
{
  ddt_msgs__msg__PMSCommand * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} ddt_msgs__msg__PMSCommand__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DDT_MSGS__MSG__DETAIL__PMS_COMMAND__STRUCT_H_
