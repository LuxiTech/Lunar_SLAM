// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from ddt_msgs:msg/UserCommand.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__USER_COMMAND__BUILDER_HPP_
#define DDT_MSGS__MSG__DETAIL__USER_COMMAND__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "ddt_msgs/msg/detail/user_command__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace ddt_msgs
{

namespace msg
{

namespace builder
{

class Init_UserCommand_twist
{
public:
  explicit Init_UserCommand_twist(::ddt_msgs::msg::UserCommand & msg)
  : msg_(msg)
  {}
  ::ddt_msgs::msg::UserCommand twist(::ddt_msgs::msg::UserCommand::_twist_type arg)
  {
    msg_.twist = std::move(arg);
    return std::move(msg_);
  }

private:
  ::ddt_msgs::msg::UserCommand msg_;
};

class Init_UserCommand_pose
{
public:
  explicit Init_UserCommand_pose(::ddt_msgs::msg::UserCommand & msg)
  : msg_(msg)
  {}
  Init_UserCommand_twist pose(::ddt_msgs::msg::UserCommand::_pose_type arg)
  {
    msg_.pose = std::move(arg);
    return Init_UserCommand_twist(msg_);
  }

private:
  ::ddt_msgs::msg::UserCommand msg_;
};

class Init_UserCommand_fsm_mode
{
public:
  explicit Init_UserCommand_fsm_mode(::ddt_msgs::msg::UserCommand & msg)
  : msg_(msg)
  {}
  Init_UserCommand_pose fsm_mode(::ddt_msgs::msg::UserCommand::_fsm_mode_type arg)
  {
    msg_.fsm_mode = std::move(arg);
    return Init_UserCommand_pose(msg_);
  }

private:
  ::ddt_msgs::msg::UserCommand msg_;
};

class Init_UserCommand_header
{
public:
  Init_UserCommand_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_UserCommand_fsm_mode header(::ddt_msgs::msg::UserCommand::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_UserCommand_fsm_mode(msg_);
  }

private:
  ::ddt_msgs::msg::UserCommand msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::ddt_msgs::msg::UserCommand>()
{
  return ddt_msgs::msg::builder::Init_UserCommand_header();
}

}  // namespace ddt_msgs

#endif  // DDT_MSGS__MSG__DETAIL__USER_COMMAND__BUILDER_HPP_
