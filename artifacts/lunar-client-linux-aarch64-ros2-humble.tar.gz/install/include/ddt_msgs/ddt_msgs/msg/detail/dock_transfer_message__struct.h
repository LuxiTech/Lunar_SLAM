// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from ddt_msgs:msg/DockTransferMessage.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__DOCK_TRANSFER_MESSAGE__STRUCT_H_
#define DDT_MSGS__MSG__DETAIL__DOCK_TRANSFER_MESSAGE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'MSG_TYPE_ACK'.
/**
  * Message type: 0=ACK, 1=COMMAND, 15=E_STOP
 */
enum
{
  ddt_msgs__msg__DockTransferMessage__MSG_TYPE_ACK = 0
};

/// Constant 'MSG_TYPE_COMMAND'.
enum
{
  ddt_msgs__msg__DockTransferMessage__MSG_TYPE_COMMAND = 1
};

/// Constant 'MSG_TYPE_E_STOP'.
enum
{
  ddt_msgs__msg__DockTransferMessage__MSG_TYPE_E_STOP = 15
};

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"

/// Struct defined in msg/DockTransferMessage in the package ddt_msgs.
/**
  * Dock transfer message for quadruped/biped mode switching
  * Corresponds to device_bridge::DockTransferMessage
 */
typedef struct ddt_msgs__msg__DockTransferMessage
{
  std_msgs__msg__Header header;
  uint8_t type;
  /// Mode flags (order must match SendDockTransfer.srv)
  /// true=Slave robot, false=Master robot
  bool is_slave;
  /// true=Quadruped mode, false=Biped mode
  bool is_quadruped;
  /// true=Balance mode, false=Cart mode
  bool is_balance;
  /// true=Error message
  bool error;
} ddt_msgs__msg__DockTransferMessage;

// Struct for a sequence of ddt_msgs__msg__DockTransferMessage.
typedef struct ddt_msgs__msg__DockTransferMessage__Sequence
{
  ddt_msgs__msg__DockTransferMessage * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} ddt_msgs__msg__DockTransferMessage__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DDT_MSGS__MSG__DETAIL__DOCK_TRANSFER_MESSAGE__STRUCT_H_
