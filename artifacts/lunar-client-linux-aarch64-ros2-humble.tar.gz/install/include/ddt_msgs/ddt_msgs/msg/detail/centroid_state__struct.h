// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from ddt_msgs:msg/CentroidState.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DETAIL__CENTROID_STATE__STRUCT_H_
#define DDT_MSGS__MSG__DETAIL__CENTROID_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'whole_body_com'
#include "geometry_msgs/msg/detail/vector3__struct.h"

/// Struct defined in msg/CentroidState in the package ddt_msgs.
typedef struct ddt_msgs__msg__CentroidState
{
  std_msgs__msg__Header header;
  geometry_msgs__msg__Vector3 whole_body_com;
  double set_tilt;
} ddt_msgs__msg__CentroidState;

// Struct for a sequence of ddt_msgs__msg__CentroidState.
typedef struct ddt_msgs__msg__CentroidState__Sequence
{
  ddt_msgs__msg__CentroidState * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} ddt_msgs__msg__CentroidState__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // DDT_MSGS__MSG__DETAIL__CENTROID_STATE__STRUCT_H_
