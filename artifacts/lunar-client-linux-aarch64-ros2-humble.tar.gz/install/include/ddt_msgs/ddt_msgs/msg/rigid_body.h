// generated from rosidl_generator_c/resource/idl.h.em
// with input from ddt_msgs:msg/RigidBody.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__RIGID_BODY_H_
#define DDT_MSGS__MSG__RIGID_BODY_H_

#include "ddt_msgs/msg/detail/rigid_body__struct.h"
#include "ddt_msgs/msg/detail/rigid_body__functions.h"
#include "ddt_msgs/msg/detail/rigid_body__type_support.h"

#endif  // DDT_MSGS__MSG__RIGID_BODY_H_
