// generated from rosidl_generator_c/resource/idl.h.em
// with input from ddt_msgs:msg/JointControlCommand.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__JOINT_CONTROL_COMMAND_H_
#define DDT_MSGS__MSG__JOINT_CONTROL_COMMAND_H_

#include "ddt_msgs/msg/detail/joint_control_command__struct.h"
#include "ddt_msgs/msg/detail/joint_control_command__functions.h"
#include "ddt_msgs/msg/detail/joint_control_command__type_support.h"

#endif  // DDT_MSGS__MSG__JOINT_CONTROL_COMMAND_H_
