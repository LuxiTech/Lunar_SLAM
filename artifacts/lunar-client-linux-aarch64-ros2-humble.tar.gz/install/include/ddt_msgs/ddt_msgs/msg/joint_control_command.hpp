// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__JOINT_CONTROL_COMMAND_HPP_
#define DDT_MSGS__MSG__JOINT_CONTROL_COMMAND_HPP_

#include "ddt_msgs/msg/detail/joint_control_command__struct.hpp"
#include "ddt_msgs/msg/detail/joint_control_command__builder.hpp"
#include "ddt_msgs/msg/detail/joint_control_command__traits.hpp"
#include "ddt_msgs/msg/detail/joint_control_command__type_support.hpp"

#endif  // DDT_MSGS__MSG__JOINT_CONTROL_COMMAND_HPP_
