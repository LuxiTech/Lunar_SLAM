// generated from rosidl_generator_c/resource/idl.h.em
// with input from ddt_msgs:msg/DockStatus.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DOCK_STATUS_H_
#define DDT_MSGS__MSG__DOCK_STATUS_H_

#include "ddt_msgs/msg/detail/dock_status__struct.h"
#include "ddt_msgs/msg/detail/dock_status__functions.h"
#include "ddt_msgs/msg/detail/dock_status__type_support.h"

#endif  // DDT_MSGS__MSG__DOCK_STATUS_H_
