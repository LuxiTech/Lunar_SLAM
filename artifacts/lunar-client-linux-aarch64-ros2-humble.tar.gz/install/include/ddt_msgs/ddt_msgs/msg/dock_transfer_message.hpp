// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__DOCK_TRANSFER_MESSAGE_HPP_
#define DDT_MSGS__MSG__DOCK_TRANSFER_MESSAGE_HPP_

#include "ddt_msgs/msg/detail/dock_transfer_message__struct.hpp"
#include "ddt_msgs/msg/detail/dock_transfer_message__builder.hpp"
#include "ddt_msgs/msg/detail/dock_transfer_message__traits.hpp"
#include "ddt_msgs/msg/detail/dock_transfer_message__type_support.hpp"

#endif  // DDT_MSGS__MSG__DOCK_TRANSFER_MESSAGE_HPP_
