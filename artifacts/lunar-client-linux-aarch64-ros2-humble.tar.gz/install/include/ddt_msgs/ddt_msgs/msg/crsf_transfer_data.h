// generated from rosidl_generator_c/resource/idl.h.em
// with input from ddt_msgs:msg/CrsfTransferData.idl
// generated code does not contain a copyright notice

#ifndef DDT_MSGS__MSG__CRSF_TRANSFER_DATA_H_
#define DDT_MSGS__MSG__CRSF_TRANSFER_DATA_H_

#include "ddt_msgs/msg/detail/crsf_transfer_data__struct.h"
#include "ddt_msgs/msg/detail/crsf_transfer_data__functions.h"
#include "ddt_msgs/msg/detail/crsf_transfer_data__type_support.h"

#endif  // DDT_MSGS__MSG__CRSF_TRANSFER_DATA_H_
