#!/bin/sh
exec /usr/bin/python3 "${0}c" "$@"
