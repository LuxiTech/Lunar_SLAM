# Copyright 2026 lunar
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Launch web control with the DDS settings used by the connected D1 robot."""

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    GroupAction,
    IncludeLaunchDescription,
    SetEnvironmentVariable,
)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
import os


def generate_launch_description():
    """Configure Fast DDS discovery and include the generic web controller."""
    package_share = get_package_share_directory("luxi_web_control")
    generic_launch = os.path.join(
        package_share,
        "launch",
        "web_control.launch.py",
    )
    return LaunchDescription([
        DeclareLaunchArgument("cmd_vel_topic", default_value="/cmd_vel"),
        DeclareLaunchArgument(
            "standard_cmd_vel_topic",
            default_value="/d1/cmd_vel_standard",
        ),
        DeclareLaunchArgument("bind_address", default_value="127.0.0.1"),
        DeclareLaunchArgument("web_ui_mode", default_value="map_portal"),
        DeclareLaunchArgument("http_port", default_value="8080"),
        DeclareLaunchArgument("d1_start_script", default_value=""),
        DeclareLaunchArgument("d1_stop_script", default_value=""),
        DeclareLaunchArgument("d1_control_log_path", default_value=""),
        DeclareLaunchArgument("camera_workspace_setup", default_value=""),
        DeclareLaunchArgument("camera_log_path", default_value=""),
        DeclareLaunchArgument("mapping_workspace_setup", default_value=""),
        DeclareLaunchArgument("mapping_log_path", default_value=""),
        DeclareLaunchArgument("navigation_workspace_setup", default_value=""),
        DeclareLaunchArgument("navigation_log_path", default_value=""),
        DeclareLaunchArgument("maps_root", default_value=""),
        DeclareLaunchArgument("semantic_maps_root", default_value=""),
        DeclareLaunchArgument(
            "config",
            default_value=os.path.join(
                package_share,
                "config",
                "web_control.yaml",
            ),
        ),
        SetEnvironmentVariable("ROS_DOMAIN_ID", "42"),
        SetEnvironmentVariable("RMW_IMPLEMENTATION", "rmw_fastrtps_cpp"),
        SetEnvironmentVariable(
            "ROS_AUTOMATIC_DISCOVERY_RANGE",
            "SUBNET",
        ),
        SetEnvironmentVariable("ROS_LOCALHOST_ONLY", "0"),
        GroupAction(
            scoped=True,
            actions=[IncludeLaunchDescription(
                PythonLaunchDescriptionSource(generic_launch),
                launch_arguments={
                    "cmd_vel_topic": LaunchConfiguration(
                        "standard_cmd_vel_topic"
                    ),
                    "bind_address": LaunchConfiguration("bind_address"),
                    "web_ui_mode": LaunchConfiguration("web_ui_mode"),
                    # The D1-facing entry point must retain posture, SDK and
                    # feedback gates even though generic D455-only mode does not.
                    "enable_d1_control": "true",
                    "http_port": LaunchConfiguration("http_port"),
                    # DDS still uses the D1 domain/network settings below, but
                    # the HTTP UI must remain reachable through every address
                    # selected by bind_address (including 0.0.0.0).
                    "restrict_http_to_d1_lan": "false",
                    "config": LaunchConfiguration("config"),
                    "d1_start_script": LaunchConfiguration("d1_start_script"),
                    "d1_stop_script": LaunchConfiguration("d1_stop_script"),
                    "d1_control_log_path": LaunchConfiguration(
                        "d1_control_log_path"
                    ),
                    "camera_workspace_setup": LaunchConfiguration(
                        "camera_workspace_setup"
                    ),
                    "camera_log_path": LaunchConfiguration("camera_log_path"),
                    "mapping_workspace_setup": LaunchConfiguration(
                        "mapping_workspace_setup"
                    ),
                    "mapping_log_path": LaunchConfiguration("mapping_log_path"),
                    "navigation_workspace_setup": LaunchConfiguration(
                        "navigation_workspace_setup"
                    ),
                    "navigation_log_path": LaunchConfiguration(
                        "navigation_log_path"
                    ),
                    "maps_root": LaunchConfiguration("maps_root"),
                    "semantic_maps_root": LaunchConfiguration(
                        "semantic_maps_root"
                    ),
                }.items(),
            )],
        ),
        Node(
            package="luxi_3d_navigation",
            executable="velocity_command_mux_node",
            name="d1_velocity_command_mux",
            output="screen",
            parameters=[{
                "manual_input_topic": LaunchConfiguration(
                    "standard_cmd_vel_topic"
                ),
                "navigation_input_topic": "/navigation/cmd_vel",
                "output_topic": LaunchConfiguration("cmd_vel_topic"),
                "navigation_active_topic": "/navigation/active",
                "navigation_stop_topic": "/navigation/task/cancel",
                "emergency_stop_topic": "/navigation/emergency_stop",
                "invert_angular_z": False,
            }],
        ),
    ])
