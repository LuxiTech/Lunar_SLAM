# generated from ament/cmake/core/templates/nameConfig.cmake.in

# prevent multiple inclusion
if(_luxi_hloc_CONFIG_INCLUDED)
  # ensure to keep the found flag the same
  if(NOT DEFINED luxi_hloc_FOUND)
    # explicitly set it to FALSE, otherwise CMake will set it to TRUE
    set(luxi_hloc_FOUND FALSE)
  elseif(NOT luxi_hloc_FOUND)
    # use separate condition to avoid uninitialized variable warning
    set(luxi_hloc_FOUND FALSE)
  endif()
  return()
endif()
set(_luxi_hloc_CONFIG_INCLUDED TRUE)

# output package information
if(NOT luxi_hloc_FIND_QUIETLY)
  message(STATUS "Found luxi_hloc: 0.1.0 (${luxi_hloc_DIR})")
endif()

# warn when using a deprecated package
if(NOT "" STREQUAL "")
  set(_msg "Package 'luxi_hloc' is deprecated")
  # append custom deprecation text if available
  if(NOT "" STREQUAL "TRUE")
    set(_msg "${_msg} ()")
  endif()
  # optionally quiet the deprecation message
  if(NOT ${luxi_hloc_DEPRECATED_QUIET})
    message(DEPRECATION "${_msg}")
  endif()
endif()

# flag package as ament-based to distinguish it after being find_package()-ed
set(luxi_hloc_FOUND_AMENT_PACKAGE TRUE)

# include all config extra files
set(_extras "")
foreach(_extra ${_extras})
  include("${luxi_hloc_DIR}/${_extra}")
endforeach()
