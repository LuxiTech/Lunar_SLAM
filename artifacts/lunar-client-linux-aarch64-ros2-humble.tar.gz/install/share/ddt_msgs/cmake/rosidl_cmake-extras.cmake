# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(ddt_msgs_IDL_FILES "msg/JointControlCommand.idl;msg/DockStatus.idl;msg/UserCommand.idl;msg/CentroidState.idl;msg/RigidBody.idl;msg/CrsfTransferData.idl;msg/DockTransferMessage.idl;msg/PMSCommand.idl;srv/SendDockTransfer.idl")
set(ddt_msgs_INTERFACE_FILES "msg/JointControlCommand.msg;msg/DockStatus.msg;msg/UserCommand.msg;msg/CentroidState.msg;msg/RigidBody.msg;msg/CrsfTransferData.msg;msg/DockTransferMessage.msg;msg/PMSCommand.msg;srv/SendDockTransfer.srv;srv/SendDockTransfer_Request.msg;srv/SendDockTransfer_Response.msg")
