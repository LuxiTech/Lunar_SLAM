# generated from rosidl_cmake/cmake/rosidl_cmake_aggregate_target-extras.cmake.in

# Create a convenience aggregate target ddt_msgs::ddt_msgs
# that links all generated interface targets, so downstream packages can use
# a single modern CMake target name instead of ${ddt_msgs_TARGETS}.
if(ddt_msgs_TARGETS AND NOT TARGET ddt_msgs::ddt_msgs)
  add_library(ddt_msgs::ddt_msgs INTERFACE IMPORTED)
  set_target_properties(ddt_msgs::ddt_msgs PROPERTIES
    INTERFACE_LINK_LIBRARIES "${ddt_msgs_TARGETS}")
endif()
