#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};


#[link(name = "ddt_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ddt_msgs__msg__JointControlCommand() -> *const std::ffi::c_void;
}

#[link(name = "ddt_msgs__rosidl_generator_c")]
extern "C" {
    fn ddt_msgs__msg__JointControlCommand__init(msg: *mut JointControlCommand) -> bool;
    fn ddt_msgs__msg__JointControlCommand__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<JointControlCommand>, size: usize) -> bool;
    fn ddt_msgs__msg__JointControlCommand__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<JointControlCommand>);
    fn ddt_msgs__msg__JointControlCommand__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<JointControlCommand>, out_seq: *mut rosidl_runtime_rs::Sequence<JointControlCommand>) -> bool;
}

// Corresponds to ddt_msgs__msg__JointControlCommand
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct JointControlCommand {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub name: rosidl_runtime_rs::Sequence<rosidl_runtime_rs::String>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub kp: rosidl_runtime_rs::Sequence<f64>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub kd: rosidl_runtime_rs::Sequence<f64>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub position: rosidl_runtime_rs::Sequence<f64>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub velocity: rosidl_runtime_rs::Sequence<f64>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub effort: rosidl_runtime_rs::Sequence<f64>,

}



impl Default for JointControlCommand {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ddt_msgs__msg__JointControlCommand__init(&mut msg as *mut _) {
        panic!("Call to ddt_msgs__msg__JointControlCommand__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for JointControlCommand {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__JointControlCommand__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__JointControlCommand__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__JointControlCommand__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for JointControlCommand {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for JointControlCommand where Self: Sized {
  const TYPE_NAME: &'static str = "ddt_msgs/msg/JointControlCommand";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ddt_msgs__msg__JointControlCommand() }
  }
}


#[link(name = "ddt_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ddt_msgs__msg__DockStatus() -> *const std::ffi::c_void;
}

#[link(name = "ddt_msgs__rosidl_generator_c")]
extern "C" {
    fn ddt_msgs__msg__DockStatus__init(msg: *mut DockStatus) -> bool;
    fn ddt_msgs__msg__DockStatus__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<DockStatus>, size: usize) -> bool;
    fn ddt_msgs__msg__DockStatus__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<DockStatus>);
    fn ddt_msgs__msg__DockStatus__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<DockStatus>, out_seq: *mut rosidl_runtime_rs::Sequence<DockStatus>) -> bool;
}

// Corresponds to ddt_msgs__msg__DockStatus
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct DockStatus {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub present: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub slave: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub connect: bool,

}



impl Default for DockStatus {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ddt_msgs__msg__DockStatus__init(&mut msg as *mut _) {
        panic!("Call to ddt_msgs__msg__DockStatus__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for DockStatus {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__DockStatus__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__DockStatus__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__DockStatus__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for DockStatus {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for DockStatus where Self: Sized {
  const TYPE_NAME: &'static str = "ddt_msgs/msg/DockStatus";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ddt_msgs__msg__DockStatus() }
  }
}


#[link(name = "ddt_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ddt_msgs__msg__UserCommand() -> *const std::ffi::c_void;
}

#[link(name = "ddt_msgs__rosidl_generator_c")]
extern "C" {
    fn ddt_msgs__msg__UserCommand__init(msg: *mut UserCommand) -> bool;
    fn ddt_msgs__msg__UserCommand__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<UserCommand>, size: usize) -> bool;
    fn ddt_msgs__msg__UserCommand__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<UserCommand>);
    fn ddt_msgs__msg__UserCommand__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<UserCommand>, out_seq: *mut rosidl_runtime_rs::Sequence<UserCommand>) -> bool;
}

// Corresponds to ddt_msgs__msg__UserCommand
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// Command manager send msg to locomotion unit.

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct UserCommand {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,

    /// robot availible fsm: transform_up，transform_down，loco，joint_pd，car，rl_*(1, 2, 3)
    pub fsm_mode: rosidl_runtime_rs::String,

    /// Robot body pose
    pub pose: geometry_msgs::msg::rmw::Pose,

    /// Speed control of robot chassis
    pub twist: geometry_msgs::msg::rmw::Twist,

}



impl Default for UserCommand {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ddt_msgs__msg__UserCommand__init(&mut msg as *mut _) {
        panic!("Call to ddt_msgs__msg__UserCommand__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for UserCommand {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__UserCommand__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__UserCommand__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__UserCommand__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for UserCommand {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for UserCommand where Self: Sized {
  const TYPE_NAME: &'static str = "ddt_msgs/msg/UserCommand";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ddt_msgs__msg__UserCommand() }
  }
}


#[link(name = "ddt_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ddt_msgs__msg__CentroidState() -> *const std::ffi::c_void;
}

#[link(name = "ddt_msgs__rosidl_generator_c")]
extern "C" {
    fn ddt_msgs__msg__CentroidState__init(msg: *mut CentroidState) -> bool;
    fn ddt_msgs__msg__CentroidState__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CentroidState>, size: usize) -> bool;
    fn ddt_msgs__msg__CentroidState__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CentroidState>);
    fn ddt_msgs__msg__CentroidState__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CentroidState>, out_seq: *mut rosidl_runtime_rs::Sequence<CentroidState>) -> bool;
}

// Corresponds to ddt_msgs__msg__CentroidState
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CentroidState {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub whole_body_com: geometry_msgs::msg::rmw::Vector3,


    // This member is not documented.
    #[allow(missing_docs)]
    pub set_tilt: f64,

}



impl Default for CentroidState {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ddt_msgs__msg__CentroidState__init(&mut msg as *mut _) {
        panic!("Call to ddt_msgs__msg__CentroidState__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CentroidState {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__CentroidState__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__CentroidState__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__CentroidState__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CentroidState {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CentroidState where Self: Sized {
  const TYPE_NAME: &'static str = "ddt_msgs/msg/CentroidState";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ddt_msgs__msg__CentroidState() }
  }
}


#[link(name = "ddt_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ddt_msgs__msg__RigidBody() -> *const std::ffi::c_void;
}

#[link(name = "ddt_msgs__rosidl_generator_c")]
extern "C" {
    fn ddt_msgs__msg__RigidBody__init(msg: *mut RigidBody) -> bool;
    fn ddt_msgs__msg__RigidBody__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<RigidBody>, size: usize) -> bool;
    fn ddt_msgs__msg__RigidBody__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<RigidBody>);
    fn ddt_msgs__msg__RigidBody__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<RigidBody>, out_seq: *mut rosidl_runtime_rs::Sequence<RigidBody>) -> bool;
}

// Corresponds to ddt_msgs__msg__RigidBody
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RigidBody {

    // This member is not documented.
    #[allow(missing_docs)]
    pub inertia: geometry_msgs::msg::rmw::Inertia,


    // This member is not documented.
    #[allow(missing_docs)]
    pub transform: geometry_msgs::msg::rmw::Pose,

}



impl Default for RigidBody {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ddt_msgs__msg__RigidBody__init(&mut msg as *mut _) {
        panic!("Call to ddt_msgs__msg__RigidBody__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for RigidBody {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__RigidBody__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__RigidBody__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__RigidBody__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for RigidBody {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for RigidBody where Self: Sized {
  const TYPE_NAME: &'static str = "ddt_msgs/msg/RigidBody";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ddt_msgs__msg__RigidBody() }
  }
}


#[link(name = "ddt_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ddt_msgs__msg__CrsfTransferData() -> *const std::ffi::c_void;
}

#[link(name = "ddt_msgs__rosidl_generator_c")]
extern "C" {
    fn ddt_msgs__msg__CrsfTransferData__init(msg: *mut CrsfTransferData) -> bool;
    fn ddt_msgs__msg__CrsfTransferData__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<CrsfTransferData>, size: usize) -> bool;
    fn ddt_msgs__msg__CrsfTransferData__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<CrsfTransferData>);
    fn ddt_msgs__msg__CrsfTransferData__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<CrsfTransferData>, out_seq: *mut rosidl_runtime_rs::Sequence<CrsfTransferData>) -> bool;
}

// Corresponds to ddt_msgs__msg__CrsfTransferData
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// crsf transfer data

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CrsfTransferData {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub version: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub error_code: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub buttons: [u8; 16],


    // This member is not documented.
    #[allow(missing_docs)]
    pub bat: [u8; 2],

}



impl Default for CrsfTransferData {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ddt_msgs__msg__CrsfTransferData__init(&mut msg as *mut _) {
        panic!("Call to ddt_msgs__msg__CrsfTransferData__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for CrsfTransferData {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__CrsfTransferData__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__CrsfTransferData__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__CrsfTransferData__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for CrsfTransferData {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for CrsfTransferData where Self: Sized {
  const TYPE_NAME: &'static str = "ddt_msgs/msg/CrsfTransferData";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ddt_msgs__msg__CrsfTransferData() }
  }
}


#[link(name = "ddt_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ddt_msgs__msg__DockTransferMessage() -> *const std::ffi::c_void;
}

#[link(name = "ddt_msgs__rosidl_generator_c")]
extern "C" {
    fn ddt_msgs__msg__DockTransferMessage__init(msg: *mut DockTransferMessage) -> bool;
    fn ddt_msgs__msg__DockTransferMessage__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<DockTransferMessage>, size: usize) -> bool;
    fn ddt_msgs__msg__DockTransferMessage__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<DockTransferMessage>);
    fn ddt_msgs__msg__DockTransferMessage__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<DockTransferMessage>, out_seq: *mut rosidl_runtime_rs::Sequence<DockTransferMessage>) -> bool;
}

// Corresponds to ddt_msgs__msg__DockTransferMessage
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]

/// Dock transfer message for quadruped/biped mode switching
/// Corresponds to device_bridge::DockTransferMessage

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct DockTransferMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub type_: u8,

    /// Mode flags (order must match SendDockTransfer.srv)
    /// true=Slave robot, false=Master robot
    pub is_slave: bool,

    /// true=Quadruped mode, false=Biped mode
    pub is_quadruped: bool,

    /// true=Balance mode, false=Cart mode
    pub is_balance: bool,

    /// true=Error message
    pub error: bool,

}

impl DockTransferMessage {
    /// Message type: 0=ACK, 1=COMMAND, 15=E_STOP
    pub const MSG_TYPE_ACK: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const MSG_TYPE_COMMAND: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const MSG_TYPE_E_STOP: u8 = 15;

}


impl Default for DockTransferMessage {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ddt_msgs__msg__DockTransferMessage__init(&mut msg as *mut _) {
        panic!("Call to ddt_msgs__msg__DockTransferMessage__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for DockTransferMessage {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__DockTransferMessage__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__DockTransferMessage__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__DockTransferMessage__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for DockTransferMessage {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for DockTransferMessage where Self: Sized {
  const TYPE_NAME: &'static str = "ddt_msgs/msg/DockTransferMessage";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ddt_msgs__msg__DockTransferMessage() }
  }
}


#[link(name = "ddt_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ddt_msgs__msg__PMSCommand() -> *const std::ffi::c_void;
}

#[link(name = "ddt_msgs__rosidl_generator_c")]
extern "C" {
    fn ddt_msgs__msg__PMSCommand__init(msg: *mut PMSCommand) -> bool;
    fn ddt_msgs__msg__PMSCommand__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<PMSCommand>, size: usize) -> bool;
    fn ddt_msgs__msg__PMSCommand__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<PMSCommand>);
    fn ddt_msgs__msg__PMSCommand__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<PMSCommand>, out_seq: *mut rosidl_runtime_rs::Sequence<PMSCommand>) -> bool;
}

// Corresponds to ddt_msgs__msg__PMSCommand
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PMSCommand {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::rmw::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub cmd: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub data: rosidl_runtime_rs::Sequence<u8>,

}



impl Default for PMSCommand {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ddt_msgs__msg__PMSCommand__init(&mut msg as *mut _) {
        panic!("Call to ddt_msgs__msg__PMSCommand__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for PMSCommand {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__PMSCommand__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__PMSCommand__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__msg__PMSCommand__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for PMSCommand {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for PMSCommand where Self: Sized {
  const TYPE_NAME: &'static str = "ddt_msgs/msg/PMSCommand";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ddt_msgs__msg__PMSCommand() }
  }
}


