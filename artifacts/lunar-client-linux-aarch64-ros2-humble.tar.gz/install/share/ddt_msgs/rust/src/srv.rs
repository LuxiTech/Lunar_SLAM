#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};




// Corresponds to ddt_msgs__srv__SendDockTransfer_Request

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SendDockTransfer_Request {
    /// Message type
    pub type_: u8,

    /// true=Slave robot, false=Master robot
    pub is_slave: bool,

    /// true=Quadruped mode, false=Biped mode
    pub is_quadruped: bool,

    /// true=Balance mode, false=Cart mode (only for COMMAND)
    pub is_balance: bool,

}

impl SendDockTransfer_Request {
    /// Request
    pub const MSG_TYPE_ACK: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const MSG_TYPE_COMMAND: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const MSG_TYPE_E_STOP: u8 = 15;

}


impl Default for SendDockTransfer_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::SendDockTransfer_Request::default())
  }
}

impl rosidl_runtime_rs::Message for SendDockTransfer_Request {
  type RmwMsg = super::srv::rmw::SendDockTransfer_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        type_: msg.type_,
        is_slave: msg.is_slave,
        is_quadruped: msg.is_quadruped,
        is_balance: msg.is_balance,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      type_: msg.type_,
      is_slave: msg.is_slave,
      is_quadruped: msg.is_quadruped,
      is_balance: msg.is_balance,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      type_: msg.type_,
      is_slave: msg.is_slave,
      is_quadruped: msg.is_quadruped,
      is_balance: msg.is_balance,
    }
  }
}


// Corresponds to ddt_msgs__srv__SendDockTransfer_Response

// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SendDockTransfer_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: std::string::String,

}



impl Default for SendDockTransfer_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::srv::rmw::SendDockTransfer_Response::default())
  }
}

impl rosidl_runtime_rs::Message for SendDockTransfer_Response {
  type RmwMsg = super::srv::rmw::SendDockTransfer_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        success: msg.success,
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      success: msg.success,
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      success: msg.success,
      message: msg.message.to_string(),
    }
  }
}






#[link(name = "ddt_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__ddt_msgs__srv__SendDockTransfer() -> *const std::ffi::c_void;
}

// Corresponds to ddt_msgs__srv__SendDockTransfer
#[allow(missing_docs, non_camel_case_types)]
pub struct SendDockTransfer;

impl rosidl_runtime_rs::Service for SendDockTransfer {
    type Request = SendDockTransfer_Request;
    type Response = SendDockTransfer_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__ddt_msgs__srv__SendDockTransfer() }
    }
}


