#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



// Corresponds to ddt_msgs__msg__JointControlCommand

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct JointControlCommand {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub name: Vec<std::string::String>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub kp: Vec<f64>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub kd: Vec<f64>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub position: Vec<f64>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub velocity: Vec<f64>,


    // This member is not documented.
    #[allow(missing_docs)]
    pub effort: Vec<f64>,

}



impl Default for JointControlCommand {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::JointControlCommand::default())
  }
}

impl rosidl_runtime_rs::Message for JointControlCommand {
  type RmwMsg = super::msg::rmw::JointControlCommand;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        name: msg.name
          .into_iter()
          .map(|elem| elem.as_str().into())
          .collect(),
        kp: msg.kp.into(),
        kd: msg.kd.into(),
        position: msg.position.into(),
        velocity: msg.velocity.into(),
        effort: msg.effort.into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
        name: msg.name
          .iter()
          .map(|elem| elem.as_str().into())
          .collect(),
        kp: msg.kp.as_slice().into(),
        kd: msg.kd.as_slice().into(),
        position: msg.position.as_slice().into(),
        velocity: msg.velocity.as_slice().into(),
        effort: msg.effort.as_slice().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      name: msg.name
          .into_iter()
          .map(|elem| elem.to_string())
          .collect(),
      kp: msg.kp
          .into_iter()
          .collect(),
      kd: msg.kd
          .into_iter()
          .collect(),
      position: msg.position
          .into_iter()
          .collect(),
      velocity: msg.velocity
          .into_iter()
          .collect(),
      effort: msg.effort
          .into_iter()
          .collect(),
    }
  }
}


// Corresponds to ddt_msgs__msg__DockStatus

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct DockStatus {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub present: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub slave: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub connect: bool,

}



impl Default for DockStatus {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::DockStatus::default())
  }
}

impl rosidl_runtime_rs::Message for DockStatus {
  type RmwMsg = super::msg::rmw::DockStatus;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        present: msg.present,
        slave: msg.slave,
        connect: msg.connect,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
      present: msg.present,
      slave: msg.slave,
      connect: msg.connect,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      present: msg.present,
      slave: msg.slave,
      connect: msg.connect,
    }
  }
}


// Corresponds to ddt_msgs__msg__UserCommand
/// Command manager send msg to locomotion unit.

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct UserCommand {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,

    /// robot availible fsm: transform_up，transform_down，loco，joint_pd，car，rl_*(1, 2, 3)
    pub fsm_mode: std::string::String,

    /// Robot body pose
    pub pose: geometry_msgs::msg::Pose,

    /// Speed control of robot chassis
    pub twist: geometry_msgs::msg::Twist,

}



impl Default for UserCommand {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::UserCommand::default())
  }
}

impl rosidl_runtime_rs::Message for UserCommand {
  type RmwMsg = super::msg::rmw::UserCommand;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        fsm_mode: msg.fsm_mode.as_str().into(),
        pose: geometry_msgs::msg::Pose::into_rmw_message(std::borrow::Cow::Owned(msg.pose)).into_owned(),
        twist: geometry_msgs::msg::Twist::into_rmw_message(std::borrow::Cow::Owned(msg.twist)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
        fsm_mode: msg.fsm_mode.as_str().into(),
        pose: geometry_msgs::msg::Pose::into_rmw_message(std::borrow::Cow::Borrowed(&msg.pose)).into_owned(),
        twist: geometry_msgs::msg::Twist::into_rmw_message(std::borrow::Cow::Borrowed(&msg.twist)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      fsm_mode: msg.fsm_mode.to_string(),
      pose: geometry_msgs::msg::Pose::from_rmw_message(msg.pose),
      twist: geometry_msgs::msg::Twist::from_rmw_message(msg.twist),
    }
  }
}


// Corresponds to ddt_msgs__msg__CentroidState

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CentroidState {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub whole_body_com: geometry_msgs::msg::Vector3,


    // This member is not documented.
    #[allow(missing_docs)]
    pub set_tilt: f64,

}



impl Default for CentroidState {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::CentroidState::default())
  }
}

impl rosidl_runtime_rs::Message for CentroidState {
  type RmwMsg = super::msg::rmw::CentroidState;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        whole_body_com: geometry_msgs::msg::Vector3::into_rmw_message(std::borrow::Cow::Owned(msg.whole_body_com)).into_owned(),
        set_tilt: msg.set_tilt,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
        whole_body_com: geometry_msgs::msg::Vector3::into_rmw_message(std::borrow::Cow::Borrowed(&msg.whole_body_com)).into_owned(),
      set_tilt: msg.set_tilt,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      whole_body_com: geometry_msgs::msg::Vector3::from_rmw_message(msg.whole_body_com),
      set_tilt: msg.set_tilt,
    }
  }
}


// Corresponds to ddt_msgs__msg__RigidBody

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RigidBody {

    // This member is not documented.
    #[allow(missing_docs)]
    pub inertia: geometry_msgs::msg::Inertia,


    // This member is not documented.
    #[allow(missing_docs)]
    pub transform: geometry_msgs::msg::Pose,

}



impl Default for RigidBody {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::RigidBody::default())
  }
}

impl rosidl_runtime_rs::Message for RigidBody {
  type RmwMsg = super::msg::rmw::RigidBody;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        inertia: geometry_msgs::msg::Inertia::into_rmw_message(std::borrow::Cow::Owned(msg.inertia)).into_owned(),
        transform: geometry_msgs::msg::Pose::into_rmw_message(std::borrow::Cow::Owned(msg.transform)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        inertia: geometry_msgs::msg::Inertia::into_rmw_message(std::borrow::Cow::Borrowed(&msg.inertia)).into_owned(),
        transform: geometry_msgs::msg::Pose::into_rmw_message(std::borrow::Cow::Borrowed(&msg.transform)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      inertia: geometry_msgs::msg::Inertia::from_rmw_message(msg.inertia),
      transform: geometry_msgs::msg::Pose::from_rmw_message(msg.transform),
    }
  }
}


// Corresponds to ddt_msgs__msg__CrsfTransferData
/// crsf transfer data

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct CrsfTransferData {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub version: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub error_code: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub buttons: [u8; 16],


    // This member is not documented.
    #[allow(missing_docs)]
    pub bat: [u8; 2],

}



impl Default for CrsfTransferData {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::CrsfTransferData::default())
  }
}

impl rosidl_runtime_rs::Message for CrsfTransferData {
  type RmwMsg = super::msg::rmw::CrsfTransferData;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        version: msg.version,
        error_code: msg.error_code,
        buttons: msg.buttons,
        bat: msg.bat,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
      version: msg.version,
      error_code: msg.error_code,
        buttons: msg.buttons,
        bat: msg.bat,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      version: msg.version,
      error_code: msg.error_code,
      buttons: msg.buttons,
      bat: msg.bat,
    }
  }
}


// Corresponds to ddt_msgs__msg__DockTransferMessage
/// Dock transfer message for quadruped/biped mode switching
/// Corresponds to device_bridge::DockTransferMessage

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct DockTransferMessage {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub type_: u8,

    /// Mode flags (order must match SendDockTransfer.srv)
    /// true=Slave robot, false=Master robot
    pub is_slave: bool,

    /// true=Quadruped mode, false=Biped mode
    pub is_quadruped: bool,

    /// true=Balance mode, false=Cart mode
    pub is_balance: bool,

    /// true=Error message
    pub error: bool,

}

impl DockTransferMessage {
    /// Message type: 0=ACK, 1=COMMAND, 15=E_STOP
    pub const MSG_TYPE_ACK: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const MSG_TYPE_COMMAND: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const MSG_TYPE_E_STOP: u8 = 15;

}


impl Default for DockTransferMessage {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::DockTransferMessage::default())
  }
}

impl rosidl_runtime_rs::Message for DockTransferMessage {
  type RmwMsg = super::msg::rmw::DockTransferMessage;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        type_: msg.type_,
        is_slave: msg.is_slave,
        is_quadruped: msg.is_quadruped,
        is_balance: msg.is_balance,
        error: msg.error,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
      type_: msg.type_,
      is_slave: msg.is_slave,
      is_quadruped: msg.is_quadruped,
      is_balance: msg.is_balance,
      error: msg.error,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      type_: msg.type_,
      is_slave: msg.is_slave,
      is_quadruped: msg.is_quadruped,
      is_balance: msg.is_balance,
      error: msg.error,
    }
  }
}


// Corresponds to ddt_msgs__msg__PMSCommand

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct PMSCommand {

    // This member is not documented.
    #[allow(missing_docs)]
    pub header: std_msgs::msg::Header,


    // This member is not documented.
    #[allow(missing_docs)]
    pub cmd: u32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub data: Vec<u8>,

}



impl Default for PMSCommand {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::PMSCommand::default())
  }
}

impl rosidl_runtime_rs::Message for PMSCommand {
  type RmwMsg = super::msg::rmw::PMSCommand;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Owned(msg.header)).into_owned(),
        cmd: msg.cmd,
        data: msg.data.into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        header: std_msgs::msg::Header::into_rmw_message(std::borrow::Cow::Borrowed(&msg.header)).into_owned(),
      cmd: msg.cmd,
        data: msg.data.as_slice().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      header: std_msgs::msg::Header::from_rmw_message(msg.header),
      cmd: msg.cmd,
      data: msg.data
          .into_iter()
          .collect(),
    }
  }
}


