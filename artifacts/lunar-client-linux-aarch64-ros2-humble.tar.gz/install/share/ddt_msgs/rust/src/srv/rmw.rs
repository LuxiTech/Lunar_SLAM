#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



#[link(name = "ddt_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ddt_msgs__srv__SendDockTransfer_Request() -> *const std::ffi::c_void;
}

#[link(name = "ddt_msgs__rosidl_generator_c")]
extern "C" {
    fn ddt_msgs__srv__SendDockTransfer_Request__init(msg: *mut SendDockTransfer_Request) -> bool;
    fn ddt_msgs__srv__SendDockTransfer_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<SendDockTransfer_Request>, size: usize) -> bool;
    fn ddt_msgs__srv__SendDockTransfer_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<SendDockTransfer_Request>);
    fn ddt_msgs__srv__SendDockTransfer_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<SendDockTransfer_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<SendDockTransfer_Request>) -> bool;
}

// Corresponds to ddt_msgs__srv__SendDockTransfer_Request
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SendDockTransfer_Request {
    /// Message type
    pub type_: u8,

    /// true=Slave robot, false=Master robot
    pub is_slave: bool,

    /// true=Quadruped mode, false=Biped mode
    pub is_quadruped: bool,

    /// true=Balance mode, false=Cart mode (only for COMMAND)
    pub is_balance: bool,

}

impl SendDockTransfer_Request {
    /// Request
    pub const MSG_TYPE_ACK: u8 = 0;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const MSG_TYPE_COMMAND: u8 = 1;


    // This constant is not documented.
    #[allow(missing_docs)]
    pub const MSG_TYPE_E_STOP: u8 = 15;

}


impl Default for SendDockTransfer_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ddt_msgs__srv__SendDockTransfer_Request__init(&mut msg as *mut _) {
        panic!("Call to ddt_msgs__srv__SendDockTransfer_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for SendDockTransfer_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__srv__SendDockTransfer_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__srv__SendDockTransfer_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__srv__SendDockTransfer_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for SendDockTransfer_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for SendDockTransfer_Request where Self: Sized {
  const TYPE_NAME: &'static str = "ddt_msgs/srv/SendDockTransfer_Request";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ddt_msgs__srv__SendDockTransfer_Request() }
  }
}


#[link(name = "ddt_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ddt_msgs__srv__SendDockTransfer_Response() -> *const std::ffi::c_void;
}

#[link(name = "ddt_msgs__rosidl_generator_c")]
extern "C" {
    fn ddt_msgs__srv__SendDockTransfer_Response__init(msg: *mut SendDockTransfer_Response) -> bool;
    fn ddt_msgs__srv__SendDockTransfer_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<SendDockTransfer_Response>, size: usize) -> bool;
    fn ddt_msgs__srv__SendDockTransfer_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<SendDockTransfer_Response>);
    fn ddt_msgs__srv__SendDockTransfer_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<SendDockTransfer_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<SendDockTransfer_Response>) -> bool;
}

// Corresponds to ddt_msgs__srv__SendDockTransfer_Response
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[allow(non_camel_case_types)]
#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SendDockTransfer_Response {

    // This member is not documented.
    #[allow(missing_docs)]
    pub success: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub message: rosidl_runtime_rs::String,

}



impl Default for SendDockTransfer_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ddt_msgs__srv__SendDockTransfer_Response__init(&mut msg as *mut _) {
        panic!("Call to ddt_msgs__srv__SendDockTransfer_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for SendDockTransfer_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__srv__SendDockTransfer_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__srv__SendDockTransfer_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ddt_msgs__srv__SendDockTransfer_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for SendDockTransfer_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for SendDockTransfer_Response where Self: Sized {
  const TYPE_NAME: &'static str = "ddt_msgs/srv/SendDockTransfer_Response";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ddt_msgs__srv__SendDockTransfer_Response() }
  }
}






#[link(name = "ddt_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__ddt_msgs__srv__SendDockTransfer() -> *const std::ffi::c_void;
}

// Corresponds to ddt_msgs__srv__SendDockTransfer
#[allow(missing_docs, non_camel_case_types)]
pub struct SendDockTransfer;

impl rosidl_runtime_rs::Service for SendDockTransfer {
    type Request = SendDockTransfer_Request;
    type Response = SendDockTransfer_Response;

    fn get_type_support() -> *const std::ffi::c_void {
        // SAFETY: No preconditions for this function.
        unsafe { rosidl_typesupport_c__get_service_type_support_handle__ddt_msgs__srv__SendDockTransfer() }
    }
}


