#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "luxi_location::luxi_location_core" for configuration "Release"
set_property(TARGET luxi_location::luxi_location_core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(luxi_location::luxi_location_core PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libluxi_location_core.a"
  )

list(APPEND _IMPORT_CHECK_TARGETS luxi_location::luxi_location_core )
list(APPEND _IMPORT_CHECK_FILES_FOR_luxi_location::luxi_location_core "${_IMPORT_PREFIX}/lib/libluxi_location_core.a" )

# Import target "luxi_location::icp_localization_node" for configuration "Release"
set_property(TARGET luxi_location::icp_localization_node APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(luxi_location::icp_localization_node PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/luxi_location/icp_localization_node"
  )

list(APPEND _IMPORT_CHECK_TARGETS luxi_location::icp_localization_node )
list(APPEND _IMPORT_CHECK_FILES_FOR_luxi_location::icp_localization_node "${_IMPORT_PREFIX}/lib/luxi_location/icp_localization_node" )

# Import target "luxi_location::offline_registration_test" for configuration "Release"
set_property(TARGET luxi_location::offline_registration_test APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(luxi_location::offline_registration_test PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/luxi_location/offline_registration_test"
  )

list(APPEND _IMPORT_CHECK_TARGETS luxi_location::offline_registration_test )
list(APPEND _IMPORT_CHECK_FILES_FOR_luxi_location::offline_registration_test "${_IMPORT_PREFIX}/lib/luxi_location/offline_registration_test" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
