# generated from ament/cmake/core/templates/nameConfig.cmake.in

# prevent multiple inclusion
if(_luxi_location_CONFIG_INCLUDED)
  # ensure to keep the found flag the same
  if(NOT DEFINED luxi_location_FOUND)
    # explicitly set it to FALSE, otherwise CMake will set it to TRUE
    set(luxi_location_FOUND FALSE)
  elseif(NOT luxi_location_FOUND)
    # use separate condition to avoid uninitialized variable warning
    set(luxi_location_FOUND FALSE)
  endif()
  return()
endif()
set(_luxi_location_CONFIG_INCLUDED TRUE)

# output package information
if(NOT luxi_location_FIND_QUIETLY)
  message(STATUS "Found luxi_location: 0.1.0 (${luxi_location_DIR})")
endif()

# warn when using a deprecated package
if(NOT "" STREQUAL "")
  set(_msg "Package 'luxi_location' is deprecated")
  # append custom deprecation text if available
  if(NOT "" STREQUAL "TRUE")
    set(_msg "${_msg} ()")
  endif()
  # optionally quiet the deprecation message
  if(NOT ${luxi_location_DEPRECATED_QUIET})
    message(DEPRECATION "${_msg}")
  endif()
endif()

# flag package as ament-based to distinguish it after being find_package()-ed
set(luxi_location_FOUND_AMENT_PACKAGE TRUE)

# include all config extra files
set(_extras "ament_cmake_export_targets-extras.cmake")
foreach(_extra ${_extras})
  include("${luxi_location_DIR}/${_extra}")
endforeach()
