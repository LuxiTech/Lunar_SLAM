#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "slam_d1_bridge::slam_d1_bridge_node" for configuration "Release"
set_property(TARGET slam_d1_bridge::slam_d1_bridge_node APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(slam_d1_bridge::slam_d1_bridge_node PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libslam_d1_bridge_node.a"
  )

list(APPEND _IMPORT_CHECK_TARGETS slam_d1_bridge::slam_d1_bridge_node )
list(APPEND _IMPORT_CHECK_FILES_FOR_slam_d1_bridge::slam_d1_bridge_node "${_IMPORT_PREFIX}/lib/libslam_d1_bridge_node.a" )

# Import target "slam_d1_bridge::slam_d1_bridge" for configuration "Release"
set_property(TARGET slam_d1_bridge::slam_d1_bridge APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(slam_d1_bridge::slam_d1_bridge PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/slam_d1_bridge/slam_d1_bridge"
  )

list(APPEND _IMPORT_CHECK_TARGETS slam_d1_bridge::slam_d1_bridge )
list(APPEND _IMPORT_CHECK_FILES_FOR_slam_d1_bridge::slam_d1_bridge "${_IMPORT_PREFIX}/lib/slam_d1_bridge/slam_d1_bridge" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
