#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "luxi_semantic_annotation::semantic_annotation_core" for configuration "Release"
set_property(TARGET luxi_semantic_annotation::semantic_annotation_core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(luxi_semantic_annotation::semantic_annotation_core PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libsemantic_annotation_core.a"
  )

list(APPEND _IMPORT_CHECK_TARGETS luxi_semantic_annotation::semantic_annotation_core )
list(APPEND _IMPORT_CHECK_FILES_FOR_luxi_semantic_annotation::semantic_annotation_core "${_IMPORT_PREFIX}/lib/libsemantic_annotation_core.a" )

# Import target "luxi_semantic_annotation::semantic_annotation_tool" for configuration "Release"
set_property(TARGET luxi_semantic_annotation::semantic_annotation_tool APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(luxi_semantic_annotation::semantic_annotation_tool PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/luxi_semantic_annotation/semantic_annotation_tool"
  )

list(APPEND _IMPORT_CHECK_TARGETS luxi_semantic_annotation::semantic_annotation_tool )
list(APPEND _IMPORT_CHECK_FILES_FOR_luxi_semantic_annotation::semantic_annotation_tool "${_IMPORT_PREFIX}/lib/luxi_semantic_annotation/semantic_annotation_tool" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
